<?php

$resp = new Symfony\Component\HttpFoundation\Response('Sorry, page not found', 404);
