<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru">
<head>
    <title>Links page</title>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
</head>
<body>
    <a href="redirector.php">Redirect me to</a>
    <a href="randomizer.php">Random number page</a>
    <a href="/links.php?quoted">Link with a '</a>
    <a href="/basic_form.php">
        <img src="basic_form" alt="basic form image"/>
    </a>
</body>
</html>
