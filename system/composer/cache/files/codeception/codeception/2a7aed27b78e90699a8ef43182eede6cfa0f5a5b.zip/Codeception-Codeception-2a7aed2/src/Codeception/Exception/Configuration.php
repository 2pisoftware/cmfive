<?php
namespace Codeception\Exception;

class Configuration extends \Exception {


}
