<!DOCTYPE html>
<html>
<head></head>
<body>
<form action="/form/example10" method="post">
    <input type="text" id="username" name="username" value="fred">
    <input type="submit" id="button1" name="button1" value="value1">
    <input type="submit" id="button2" name="button2" value="value2">
</form>
</body>
</html>
