<?php 
namespace Codeception\Platform;

use Codeception\Extension as BaseExtension;

/**
 * BC Compatibility
 *
 * Class Extension
 * @package Codeception\Platform
 */
abstract class Extension extends BaseExtension
{

}
