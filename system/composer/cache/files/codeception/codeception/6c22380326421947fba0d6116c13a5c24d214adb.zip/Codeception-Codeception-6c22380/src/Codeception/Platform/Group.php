<?php 
namespace Codeception\Platform;

use Codeception\GroupObject;

/**
 * BC compatibility
 *
 * Class Group
 * @package Codeception\Platform
 */
abstract class Group extends GroupObject
{
}
