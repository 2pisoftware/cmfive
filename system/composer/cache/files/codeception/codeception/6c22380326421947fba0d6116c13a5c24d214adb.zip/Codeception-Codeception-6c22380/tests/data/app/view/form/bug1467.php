<!doctype html>
<html>
    <head><title>hi</title></head>
    <body>
        TEST TEST
        <form name="form1">
            <label><input type="radio" name="first_test_radio" value="Yes"/>Yes</label>
            <label><input type="radio" name="first_test_radio" value="No"/>No</label>
            <br/>
            <label><input type="radio" name="second_test_radio" value="Yes" />Yes</label>
            <label><input type="radio" name="second_test_radio" value="No" />No</label>
        </form>
        <form name="form2">
            <label><input type="radio" name="first_test_radio" value="Yes"/>Yes</label>
            <label><input type="radio" name="first_test_radio" value="No"/>No</label>
            <br/>
            <label><input type="radio" name="second_test_radio" value="Yes" />Yes</label>
            <label><input type="radio" name="second_test_radio" value="No" />No</label>
        </form>
    </body>
</html>
