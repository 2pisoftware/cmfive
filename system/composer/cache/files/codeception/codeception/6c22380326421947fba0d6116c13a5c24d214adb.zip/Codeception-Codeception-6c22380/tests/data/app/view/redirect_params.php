<html>
<head>
    <meta http-equiv="refresh" content="0; url=http://localhost:8000/search?one=1&amp;two=2" />
</head>
<body>
    <h1>Redirecting...</h1>
</body>
</html>

