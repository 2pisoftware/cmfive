<?php

namespace Math;

class Subtractor
{
    public function perform($a, $b)
    {
        return $a - $b;
    }
}
