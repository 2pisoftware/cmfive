<html>
<head>
    <meta http-equiv="refresh" content="1800; url=http://localhost:8000/info" />
</head>
<body>
    <h1>Redirecting in 1800 seconds</h1>
</body>
</html>