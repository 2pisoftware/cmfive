<html>
<body>
<form action="/form/complex" method="POST">
    <label for="description">Description</label>
    <textarea name="description" id="description" cols="30" rows="10">sunrise</textarea>
    <input type="submit" value="Submit" />
</form>
</body>
</html>