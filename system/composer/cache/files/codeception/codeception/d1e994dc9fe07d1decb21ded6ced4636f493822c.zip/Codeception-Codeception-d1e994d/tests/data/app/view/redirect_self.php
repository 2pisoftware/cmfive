<html>
<head>
    <meta http-equiv="refresh" content="9; url=http://localhost:8000/redirect_self" />
</head>
<body>
    <h1>Redirecting to myself (page refresh)</h1>
</body>
</html>