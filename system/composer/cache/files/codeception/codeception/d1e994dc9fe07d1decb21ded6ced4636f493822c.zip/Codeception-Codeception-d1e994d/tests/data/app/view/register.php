<!DOCTYPE html>
<html>
<head>
<base href="http://127.0.0.1:8000">
<meta charset="utf-8">
<title>Test submitting a form with a relative URL without a leading slash as its action from a URI in the root directory</title>
</head>
<body>
<form method="post" action="register">
<input type="text" name="test" value="" />
<input type="submit" name="submit" value="Submit" />
</form>
</body>
</html>