<?php
\Codeception\Module\OrderHelper::appendToFile('B');