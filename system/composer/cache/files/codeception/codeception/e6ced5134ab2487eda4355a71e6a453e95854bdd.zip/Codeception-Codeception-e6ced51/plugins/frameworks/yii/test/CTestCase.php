<?php

abstract class CTestCase extends PHPUnit_Framework_TestCase
{
}