[single quotes](http://example.com 'Title')

[double quotes](http://example.com "Title")

[space](http://example.com "2 Words")

[parentheses](http://example.com/url-(parentheses) "Title")