<?php

require_once __DIR__ . '/../lib/__init__.php';
require_once __DIR__ . '/functional/WebDriverTestCase.php';
