<?php

namespace Herrera\Json\Exception;

/**
 * Indicates that the exception came from this library.
 *
 * @author Kevin Herrera <kevin@herrera.io>
 */
interface ExceptionInterface
{
}
