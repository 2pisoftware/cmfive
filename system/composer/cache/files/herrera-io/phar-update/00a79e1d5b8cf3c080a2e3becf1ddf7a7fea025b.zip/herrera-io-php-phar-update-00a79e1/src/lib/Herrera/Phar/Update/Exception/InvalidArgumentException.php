<?php

namespace Herrera\Phar\Update\Exception;

/**
 * Used if an invalid argument is given.
 *
 * @author Kevin Herrera <kevin@herrera.io>
 */
class InvalidArgumentException extends Exception
{
}
