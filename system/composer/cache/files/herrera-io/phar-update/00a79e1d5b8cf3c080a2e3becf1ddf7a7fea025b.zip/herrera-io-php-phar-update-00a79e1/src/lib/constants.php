<?php

if (!defined('PHAR_UPDATE_MANIFEST_SCHEMA')) {

    /**
     * The manifest schema file.
     *
     * @var string
     */
    define('PHAR_UPDATE_MANIFEST_SCHEMA', __DIR__ . '/../../res/schema.json');

}
