<?php

namespace Metadata\Tests\Driver\Fixture\T;

trait T {}
