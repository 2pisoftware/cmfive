<?php

namespace Metadata\Tests\Fixtures\ComplexHierarchy;

abstract class BaseClass implements InterfaceA
{
    private $foo;
}