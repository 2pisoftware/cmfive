<?php

namespace Metadata\Tests\Fixtures;

class TestParent extends TestObject
{
}