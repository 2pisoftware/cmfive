<?php

namespace Gaufrette\Functional\Adapter;

use Gaufrette\Adapter\Dropbox;

class DropboxTest extends FunctionalTestCase
{
}
