<?php

namespace Gaufrette;

/**
 * Interface for the Gaufrette related exceptions
 *
 * @author Antoine Hérault <antoine.herault@gmail.com>
 */
interface Exception
{
}
