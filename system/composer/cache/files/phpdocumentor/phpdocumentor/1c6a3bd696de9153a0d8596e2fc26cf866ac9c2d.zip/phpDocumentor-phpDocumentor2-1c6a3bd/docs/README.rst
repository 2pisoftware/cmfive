README
======

This folder contains the next generation of documentation written to enable readers to
easily find what they are looking for and reduce the academic level of the current
writing style.

Once deemed complete by us will the contents of this folder be promoted to the ``/docs/``
folder and will the ``/docs/manual`` folder be removed.

.. important::

    This set of documentation should not be made publicly available on the website until release; this will prevent
    google from indexing and as such we will not have to make URL redirects once we move this folder's contents.

