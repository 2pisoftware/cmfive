Cookbook
--------

.. toctree::
   :maxdepth: 2
