Extending phpDocumentor
=======================

phpDocumentor has been designed to allow developers to write add-ons with which additional behaviour can be introduced.
This behaviour may be additional tags, documentation validations, warnings sent when a threshold is reached and
anything else that you can imagine.

Creating a Service Provider
---------------------------

Bring Tags to Life
------------------

Write Content the Way You Want
------------------------------

