Getting started
===============

.. toctree::
    :maxdepth: 2

    installing
    your-first-set-of-documentation
    changing-the-look-and-feel

.. toctree::
   :hidden:

   extending-phpdocumentor
