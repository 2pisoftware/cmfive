Guides
======

.. toctree::
   :maxdepth: 2

   docblocks
   types
   inheritance
   running-phpdocumentor
   manuals/index

.. toctree::
   :hidden:

   project-integration
   templates
   service-providers
