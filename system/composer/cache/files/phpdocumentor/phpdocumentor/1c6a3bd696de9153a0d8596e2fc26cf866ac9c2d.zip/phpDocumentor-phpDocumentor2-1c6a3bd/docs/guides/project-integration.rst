Project Integration
===================

.. note:: this is still a placeholder document; more content will be added

Configuration
-------------

IDE
---

Continuous Integration
----------------------
