Learn about phpDocumentor
=========================

.. toctree::
    :maxdepth: 2

    welcome
    getting-started/index
    guides/index
    references/index
    internals/index
    cookbook/index
    glossary
