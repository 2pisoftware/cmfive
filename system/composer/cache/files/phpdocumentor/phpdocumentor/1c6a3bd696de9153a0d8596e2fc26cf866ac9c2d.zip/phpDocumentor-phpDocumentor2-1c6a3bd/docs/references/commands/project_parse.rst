project:parse
=============

.. note::

   The contents for this chapter have not been written yet. Why not help us and
   contribute it at
   https://github.com/phpDocumentor/phpDocumentor2/tree/develop/docs
