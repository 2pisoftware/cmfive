template:list
=============

Description
-----------

This command will give a list of all the templates available in your PHPDocumentor installation

Usage
-----

::

    $ phpdoc template:list
