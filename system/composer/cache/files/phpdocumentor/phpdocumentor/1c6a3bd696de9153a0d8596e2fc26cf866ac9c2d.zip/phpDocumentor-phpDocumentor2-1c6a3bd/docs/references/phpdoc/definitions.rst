Definitions
===========
