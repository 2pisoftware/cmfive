PHPDoc reference
================

.. toctree::
   :maxdepth: 2

   basic-syntax
   inheritance
   types
   inline-tags/index
   tags/index
   definitions
