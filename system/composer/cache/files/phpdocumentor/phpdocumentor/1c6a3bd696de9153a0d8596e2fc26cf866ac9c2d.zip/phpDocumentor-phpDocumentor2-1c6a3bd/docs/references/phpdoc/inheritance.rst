Inheritance
===========

.. note:: This document needs to be written
