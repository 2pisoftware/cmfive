Inline tag reference
====================

.. toctree::
   :maxdepth: 1

   example
   internal
   inheritdoc
   link
   see
