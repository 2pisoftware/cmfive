Internals
=========

.. toctree::

  internals/introduction
  internals/theory_of_operation
  internals/formats
  internals/converters
  internals/metadata
  internals/search
  internals/templates
  internals/plugins
