<?php

// This file has no class in
// Regression of #87 https://github.com/phpdocumentor/phpdocumentor2/issues/87
