Reflection [![Build Status](https://secure.travis-ci.org/phpDocumentor/Reflection.png)](http://travis-ci.org/phpDocumentor/Reflection)
==========

Reflection library to do Static Analysis for PHP Projects
