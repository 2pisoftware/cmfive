template.xml
============

Generates an XML representation of the project's structure
