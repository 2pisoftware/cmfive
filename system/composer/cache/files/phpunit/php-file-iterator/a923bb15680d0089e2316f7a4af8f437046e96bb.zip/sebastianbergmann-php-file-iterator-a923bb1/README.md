# File_Iterator

## Installation

To add File_Iterator as a local, per-project dependency to your project, simply add a dependency on `phpunit/php-file-iterator` to your project's `composer.json` file. Here is a minimal example of a `composer.json` file that just defines a dependency on File_Iterator 1.4:

    {
        "require": {
            "phpunit/php-file-iterator": "~1.4"
        }
    }

