<?php
require __DIR__ . '/../vendor/autoload.php';
require __DIR__ . '/autoload.php';

ini_set('precision', 14);
ini_set('serialize_precision', 14);

