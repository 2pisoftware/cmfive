<?php
    header('Location: network_confirm.php');
?><html>
    <head><title>Redirection test</title></head>
    <body>This is a test page for the SimpleTest PHP unit tester</body>
</html>