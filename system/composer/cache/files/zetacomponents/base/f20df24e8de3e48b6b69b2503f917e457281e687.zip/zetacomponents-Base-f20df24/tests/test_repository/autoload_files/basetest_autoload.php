<?php
return array(
	'trBasetestClass' => 'TestClasses/base_test_class.php',
	'trBasetestClass2' => 'TestClasses/base_test_class_number_two.php',
	'trBasetestClass4' => 'TestClasses/base_test_class_number_four.php',
);
?>
