-- MySQL dump 10.13  Distrib 5.6.16, for osx10.9 (x86_64)
--
-- Host: localhost    Database: crm2pi
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attachment`
--

DROP TABLE IF EXISTS `attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attachment` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `parent_table` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `parent_id` bigint(20) NOT NULL,
  `dt_created` datetime NOT NULL,
  `dt_modified` datetime DEFAULT NULL,
  `modifier_user_id` bigint(20) DEFAULT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mimetype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `fullpath` text COLLATE utf8_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `type_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachment`
--

LOCK TABLES `attachment` WRITE;
/*!40000 ALTER TABLE `attachment` DISABLE KEYS */;
INSERT INTO `attachment` VALUES (1,'task',39,'2014-04-14 11:33:14','2014-04-14 11:34:06',NULL,'bg-section-1.jpg','image/jpeg','BG Section','BG section','attachments/task/2014/04/14/bg-section-1.jpg',1,NULL);
/*!40000 ALTER TABLE `attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachment_type`
--

DROP TABLE IF EXISTS `attachment_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attachment_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `table_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachment_type`
--

LOCK TABLES `attachment_type` WRITE;
/*!40000 ALTER TABLE `attachment_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachment_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit`
--

DROP TABLE IF EXISTS `audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `dt_created` datetime DEFAULT NULL,
  `creator_id` bigint(20) DEFAULT NULL,
  `module` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `action` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `db_class` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `db_action` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `db_id` bigint(20) DEFAULT NULL,
  `submodule` text COLLATE utf8_unicode_ci,
  `message` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1079 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit`
--

LOCK TABLES `audit` WRITE;
/*!40000 ALTER TABLE `audit` DISABLE KEYS */;
INSERT INTO `audit` VALUES (1,'2014-03-21 15:46:31',1,'crm','edit','/crm-accounts/edit/','127.0.0.1','CrmAccount','insert',1,NULL,NULL),(2,'2014-04-07 12:21:44',1,'auth','profile','/auth/profile','127.0.0.1','User','update',1,NULL,NULL),(3,'2014-04-07 12:21:44',1,'auth','profile','/auth/profile','127.0.0.1','Contact','update',1,NULL,NULL),(4,'2014-04-07 16:14:24',1,'admin','editprinter','/admin/editprinter/','127.0.0.1','Printer','insert',2,NULL,NULL),(5,'2014-04-07 16:14:28',1,'admin','editprinter','/admin/editprinter/1','127.0.0.1','Printer','update',1,NULL,NULL),(6,'2014-04-07 16:14:30',1,'admin','deleteprinter','/admin/deleteprinter/1','127.0.0.1','Printer','delete',1,NULL,NULL),(7,'2014-04-07 16:14:33',1,'admin','deleteprinter','/admin/deleteprinter/2','127.0.0.1','Printer','delete',2,NULL,NULL),(8,'2014-04-11 14:41:27',1,'crm','edit','/crm-accounts/edit/1','127.0.0.1','CrmAccount','update',1,NULL,NULL),(9,'2014-04-11 14:52:00',1,'crm','edit','/crm-contacts/edit/','127.0.0.1','Contact','insert',2,NULL,NULL),(10,'2014-04-11 14:52:00',1,'crm','edit','/crm-contacts/edit/','127.0.0.1','CrmContact','insert',1,NULL,NULL),(19,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','ObjectIndex','insert',4,NULL,NULL),(20,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','CrmOpportunity','insert',6,NULL,NULL),(21,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','ObjectIndex','update',4,NULL,NULL),(22,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','CrmOpportunity','update',6,NULL,NULL),(23,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','ObjectIndex','insert',5,NULL,NULL),(24,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','CrmOpportunity','insert',7,NULL,NULL),(25,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','ObjectIndex','update',5,NULL,NULL),(26,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','CrmOpportunity','update',7,NULL,NULL),(27,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','ObjectIndex','insert',6,NULL,NULL),(28,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','CrmOpportunity','insert',8,NULL,NULL),(29,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','TaskComment','insert',1,NULL,NULL),(30,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','ObjectIndex','update',6,NULL,NULL),(31,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','CrmOpportunity','update',8,NULL,NULL),(32,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','ObjectIndex','insert',7,NULL,NULL),(33,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','CrmOpportunity','insert',9,NULL,NULL),(34,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','TaskComment','insert',2,NULL,NULL),(35,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','ObjectIndex','update',7,NULL,NULL),(36,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','CrmOpportunity','update',9,NULL,NULL),(37,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','ObjectIndex','insert',8,NULL,NULL),(38,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','CrmOpportunity','insert',10,NULL,NULL),(39,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','TaskComment','insert',3,NULL,NULL),(40,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','ObjectIndex','update',8,NULL,NULL),(41,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','CrmOpportunity','update',10,NULL,NULL),(42,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','ObjectIndex','insert',9,NULL,NULL),(43,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','CrmOpportunity','insert',11,NULL,NULL),(44,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','ObjectModification','insert',3,NULL,NULL),(45,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','ObjectIndex','insert',10,NULL,NULL),(46,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','Task','insert',1,NULL,NULL),(47,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','TaskComment','insert',4,NULL,NULL),(48,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','ObjectIndex','update',9,NULL,NULL),(49,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','CrmOpportunity','update',11,NULL,NULL),(50,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','ObjectIndex','insert',11,NULL,NULL),(51,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','CrmOpportunity','insert',12,NULL,NULL),(52,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','ObjectModification','insert',4,NULL,NULL),(53,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','ObjectIndex','insert',12,NULL,NULL),(54,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','Task','insert',2,NULL,NULL),(55,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','TaskComment','insert',5,NULL,NULL),(56,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','ObjectIndex','update',11,NULL,NULL),(57,NULL,NULL,'crm','edit','/crm-opportunities/edit/','127.0.0.1','CrmOpportunity','update',12,NULL,NULL),(58,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',5,NULL,NULL),(59,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',13,NULL,NULL),(60,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',3,NULL,NULL),(61,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',6,NULL,NULL),(62,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',6,NULL,NULL),(63,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',14,NULL,NULL),(64,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',4,NULL,NULL),(65,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',7,NULL,NULL),(66,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',7,NULL,NULL),(67,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',15,NULL,NULL),(68,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',5,NULL,NULL),(69,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',8,NULL,NULL),(70,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',8,NULL,NULL),(71,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',16,NULL,NULL),(72,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',6,NULL,NULL),(73,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',9,NULL,NULL),(74,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',9,NULL,NULL),(75,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',17,NULL,NULL),(76,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',7,NULL,NULL),(77,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',10,NULL,NULL),(78,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',10,NULL,NULL),(79,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',18,NULL,NULL),(80,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',8,NULL,NULL),(81,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',11,NULL,NULL),(82,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',11,NULL,NULL),(83,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',19,NULL,NULL),(84,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',9,NULL,NULL),(85,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',12,NULL,NULL),(86,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',12,NULL,NULL),(87,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',20,NULL,NULL),(88,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',10,NULL,NULL),(89,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',13,NULL,NULL),(90,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',13,NULL,NULL),(91,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',21,NULL,NULL),(92,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',11,NULL,NULL),(93,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',14,NULL,NULL),(94,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',14,NULL,NULL),(95,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',22,NULL,NULL),(96,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',12,NULL,NULL),(97,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',15,NULL,NULL),(98,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',15,NULL,NULL),(99,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',23,NULL,NULL),(100,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',13,NULL,NULL),(101,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',16,NULL,NULL),(102,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',16,NULL,NULL),(103,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',24,NULL,NULL),(104,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',14,NULL,NULL),(105,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',17,NULL,NULL),(106,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',17,NULL,NULL),(107,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',25,NULL,NULL),(108,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',15,NULL,NULL),(109,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',18,NULL,NULL),(110,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',18,NULL,NULL),(111,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',26,NULL,NULL),(112,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',16,NULL,NULL),(113,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',19,NULL,NULL),(114,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',19,NULL,NULL),(115,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',27,NULL,NULL),(116,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',17,NULL,NULL),(117,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',20,NULL,NULL),(118,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',20,NULL,NULL),(119,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',28,NULL,NULL),(120,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',18,NULL,NULL),(121,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',21,NULL,NULL),(122,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',21,NULL,NULL),(123,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',29,NULL,NULL),(124,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',19,NULL,NULL),(125,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',22,NULL,NULL),(126,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',22,NULL,NULL),(127,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',30,NULL,NULL),(128,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',20,NULL,NULL),(129,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',23,NULL,NULL),(130,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',23,NULL,NULL),(131,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',31,NULL,NULL),(132,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',21,NULL,NULL),(133,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',24,NULL,NULL),(134,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',24,NULL,NULL),(135,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',32,NULL,NULL),(136,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',22,NULL,NULL),(137,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',25,NULL,NULL),(138,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',25,NULL,NULL),(139,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',33,NULL,NULL),(140,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',23,NULL,NULL),(141,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',26,NULL,NULL),(142,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',26,NULL,NULL),(143,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',34,NULL,NULL),(144,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',24,NULL,NULL),(145,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',27,NULL,NULL),(146,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',27,NULL,NULL),(147,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',35,NULL,NULL),(148,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',25,NULL,NULL),(149,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',28,NULL,NULL),(150,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',28,NULL,NULL),(151,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',36,NULL,NULL),(152,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',26,NULL,NULL),(153,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',29,NULL,NULL),(154,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',29,NULL,NULL),(155,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',37,NULL,NULL),(156,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',27,NULL,NULL),(157,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',30,NULL,NULL),(158,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',30,NULL,NULL),(159,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',38,NULL,NULL),(160,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',28,NULL,NULL),(161,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',31,NULL,NULL),(162,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',31,NULL,NULL),(163,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',39,NULL,NULL),(164,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',29,NULL,NULL),(165,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',32,NULL,NULL),(166,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',32,NULL,NULL),(167,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',40,NULL,NULL),(168,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',30,NULL,NULL),(169,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',33,NULL,NULL),(170,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',33,NULL,NULL),(171,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',41,NULL,NULL),(172,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',31,NULL,NULL),(173,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',34,NULL,NULL),(174,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',34,NULL,NULL),(175,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',42,NULL,NULL),(176,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',32,NULL,NULL),(177,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',35,NULL,NULL),(178,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',35,NULL,NULL),(179,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',43,NULL,NULL),(180,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',33,NULL,NULL),(181,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',36,NULL,NULL),(182,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',36,NULL,NULL),(183,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',44,NULL,NULL),(184,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',34,NULL,NULL),(185,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',37,NULL,NULL),(186,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',37,NULL,NULL),(187,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',45,NULL,NULL),(188,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',35,NULL,NULL),(189,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',38,NULL,NULL),(190,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',38,NULL,NULL),(191,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',46,NULL,NULL),(192,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',36,NULL,NULL),(193,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',39,NULL,NULL),(194,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',47,NULL,NULL),(195,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','CrmOpportunity','update',1,NULL,NULL),(196,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',39,NULL,NULL),(197,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',48,NULL,NULL),(198,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',37,NULL,NULL),(199,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',40,NULL,NULL),(200,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',49,NULL,NULL),(201,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','CrmOpportunity','update',2,NULL,NULL),(202,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',40,NULL,NULL),(203,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',50,NULL,NULL),(204,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',38,NULL,NULL),(205,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',41,NULL,NULL),(206,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',51,NULL,NULL),(207,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','CrmOpportunity','update',3,NULL,NULL),(208,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',41,NULL,NULL),(209,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',52,NULL,NULL),(210,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',39,NULL,NULL),(211,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',42,NULL,NULL),(212,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',53,NULL,NULL),(213,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','CrmOpportunity','update',4,NULL,NULL),(214,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',42,NULL,NULL),(215,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',54,NULL,NULL),(216,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',40,NULL,NULL),(217,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',43,NULL,NULL),(218,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','update',3,NULL,NULL),(219,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','CrmOpportunity','update',5,NULL,NULL),(220,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',43,NULL,NULL),(221,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',55,NULL,NULL),(222,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',41,NULL,NULL),(223,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',44,NULL,NULL),(224,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','update',4,NULL,NULL),(225,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','CrmOpportunity','update',6,NULL,NULL),(226,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',44,NULL,NULL),(227,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',56,NULL,NULL),(228,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',42,NULL,NULL),(229,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',45,NULL,NULL),(230,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','update',5,NULL,NULL),(231,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','CrmOpportunity','update',7,NULL,NULL),(232,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',45,NULL,NULL),(233,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',57,NULL,NULL),(234,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',43,NULL,NULL),(235,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',46,NULL,NULL),(236,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','update',6,NULL,NULL),(237,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','CrmOpportunity','update',8,NULL,NULL),(238,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',46,NULL,NULL),(239,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',58,NULL,NULL),(240,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',44,NULL,NULL),(241,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',47,NULL,NULL),(242,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','update',7,NULL,NULL),(243,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','CrmOpportunity','update',9,NULL,NULL),(244,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectModification','insert',47,NULL,NULL),(245,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','insert',59,NULL,NULL),(246,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','Task','insert',45,NULL,NULL),(247,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','TaskComment','insert',48,NULL,NULL),(248,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','ObjectIndex','update',8,NULL,NULL),(249,NULL,NULL,'crm','index','/crm-opportunities','127.0.0.1','CrmOpportunity','update',10,NULL,NULL),(250,NULL,NULL,'admin','comment','/admin/comment//task/39','127.0.0.1','Comment','insert',49,NULL,NULL),(251,NULL,NULL,'admin','comment','/admin/comment//task/39','127.0.0.1','Comment','insert',50,NULL,NULL),(252,'2014-04-14 10:58:01',1,'admin','comment','/admin/comment//task/39','127.0.0.1','Comment','insert',51,NULL,NULL),(253,'2014-04-14 11:33:14',1,'file','attach','/file/attach','127.0.0.1','ObjectIndex','insert',60,NULL,NULL),(254,'2014-04-14 11:33:14',1,'file','attach','/file/attach','127.0.0.1','Attachment','insert',1,NULL,NULL),(255,'2014-04-14 11:34:06',1,'file','atdel','/file/atdel/1/crm-opportunities+show+4','127.0.0.1','ObjectIndex','update',60,NULL,NULL),(256,'2014-04-14 11:34:06',1,'file','atdel','/file/atdel/1/crm-opportunities+show+4','127.0.0.1','Attachment','update',1,NULL,NULL),(257,'2014-04-14 11:34:06',1,'file','atdel','/file/atdel/1/crm-opportunities+show+4','127.0.0.1','ObjectIndex','delete',60,NULL,NULL),(258,'2014-04-14 11:34:06',1,'file','atdel','/file/atdel/1/crm-opportunities+show+4','127.0.0.1','Attachment','delete',1,NULL,NULL),(259,'2014-04-14 14:06:47',1,'crm','termsedit','/crm-admin/termsedit/','127.0.0.1','CrmTerm','insert',1,NULL,NULL),(260,'2014-04-14 14:10:26',1,'crm','termsedit','/crm-admin/termsedit/','127.0.0.1','CrmTerm','insert',2,NULL,NULL),(261,'2014-04-14 14:10:30',1,'crm','termsdelete','/crm-admin/termsdelete/1','127.0.0.1','CrmTerm','update',1,NULL,NULL),(262,'2014-04-14 14:10:30',1,'crm','termsdelete','/crm-admin/termsdelete/1','127.0.0.1','CrmTerm','delete',1,NULL,NULL),(263,'2014-04-14 14:11:01',1,'crm','companyedit','/crm-admin/companyedit/','127.0.0.1','CrmCompanySetting','insert',1,NULL,NULL),(264,'2014-04-14 14:12:30',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','CrmForm','insert',1,NULL,NULL),(265,'2014-04-14 14:12:30',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','ObjectModification','insert',48,NULL,NULL),(266,'2014-04-14 14:12:30',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','TaskGroup','insert',3,NULL,NULL),(267,'2014-04-14 14:12:30',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','TaskGroupNotify','insert',13,NULL,NULL),(268,'2014-04-14 14:12:30',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','TaskGroupNotify','insert',14,NULL,NULL),(269,'2014-04-14 14:12:30',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','TaskGroupNotify','insert',15,NULL,NULL),(270,'2014-04-14 14:12:30',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','TaskGroupNotify','insert',16,NULL,NULL),(271,'2014-04-14 14:12:30',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','TaskGroupNotify','insert',17,NULL,NULL),(272,'2014-04-14 14:12:30',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','TaskGroupNotify','insert',18,NULL,NULL),(273,'2014-04-14 14:12:30',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','TaskGroupMember','insert',3,NULL,NULL),(274,'2014-04-14 14:12:30',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','ObjectModification','insert',49,NULL,NULL),(275,'2014-04-14 14:12:30',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','ObjectIndex','insert',61,NULL,NULL),(276,'2014-04-14 14:12:30',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','Task','insert',46,NULL,NULL),(277,'2014-04-14 14:12:30',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','TaskComment','insert',52,NULL,NULL),(278,'2014-04-14 14:12:30',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','CrmQuote','update',NULL,NULL,NULL),(279,'2014-04-14 14:12:30',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','CrmForm','update',1,NULL,NULL),(280,'2014-04-14 14:12:30',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','CrmForm','update',1,NULL,NULL),(281,'2014-04-14 14:13:46',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','CrmForm','insert',2,NULL,NULL),(282,'2014-04-14 14:13:46',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','ObjectModification','insert',50,NULL,NULL),(283,'2014-04-14 14:13:46',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','ObjectIndex','insert',62,NULL,NULL),(284,'2014-04-14 14:13:46',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','Task','insert',47,NULL,NULL),(285,'2014-04-14 14:13:46',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','TaskComment','insert',53,NULL,NULL),(286,'2014-04-14 14:13:46',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','CrmQuote','update',NULL,NULL,NULL),(287,'2014-04-14 14:13:46',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','CrmForm','update',2,NULL,NULL),(288,'2014-04-14 14:13:46',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','CrmForm','update',2,NULL,NULL),(289,'2014-04-14 14:20:30',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','CrmForm','insert',3,NULL,NULL),(290,'2014-04-14 14:20:30',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','ObjectModification','insert',51,NULL,NULL),(291,'2014-04-14 14:20:30',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','ObjectIndex','insert',63,NULL,NULL),(292,'2014-04-14 14:20:30',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','Task','insert',48,NULL,NULL),(293,'2014-04-14 14:20:30',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','TaskComment','insert',54,NULL,NULL),(294,'2014-04-14 14:20:30',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','CrmQuote','update',NULL,NULL,NULL),(295,'2014-04-14 14:20:42',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','CrmForm','insert',4,NULL,NULL),(296,'2014-04-14 14:20:42',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','ObjectModification','insert',52,NULL,NULL),(297,'2014-04-14 14:20:42',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','ObjectIndex','insert',64,NULL,NULL),(298,'2014-04-14 14:20:42',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','Task','insert',49,NULL,NULL),(299,'2014-04-14 14:20:42',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','TaskComment','insert',55,NULL,NULL),(300,'2014-04-14 14:20:42',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','CrmQuote','update',NULL,NULL,NULL),(301,'2014-04-14 14:21:58',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','CrmForm','insert',5,NULL,NULL),(302,'2014-04-14 14:21:58',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','ObjectIndex','insert',65,NULL,NULL),(303,'2014-04-14 14:21:58',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','CrmQuote','insert',1,NULL,NULL),(304,'2014-04-14 14:21:58',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','ObjectModification','insert',53,NULL,NULL),(305,'2014-04-14 14:21:58',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','ObjectIndex','insert',66,NULL,NULL),(306,'2014-04-14 14:21:58',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','Task','insert',50,NULL,NULL),(307,'2014-04-14 14:21:58',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','TaskComment','insert',56,NULL,NULL),(308,'2014-04-14 14:21:58',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','ObjectIndex','update',65,NULL,NULL),(309,'2014-04-14 14:21:58',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','CrmQuote','update',1,NULL,NULL),(310,'2014-04-14 14:22:17',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','CrmForm','insert',6,NULL,NULL),(311,'2014-04-14 14:22:17',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','ObjectIndex','insert',67,NULL,NULL),(312,'2014-04-14 14:22:17',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','CrmQuote','insert',2,NULL,NULL),(313,'2014-04-14 14:22:17',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','ObjectModification','insert',54,NULL,NULL),(314,'2014-04-14 14:22:17',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','ObjectIndex','insert',68,NULL,NULL),(315,'2014-04-14 14:22:17',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','Task','insert',51,NULL,NULL),(316,'2014-04-14 14:22:17',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','TaskComment','insert',57,NULL,NULL),(317,'2014-04-14 14:22:17',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','ObjectIndex','update',67,NULL,NULL),(318,'2014-04-14 14:22:17',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','CrmQuote','update',2,NULL,NULL),(319,'2014-04-14 14:22:17',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','CrmForm','update',6,NULL,NULL),(320,'2014-04-14 14:22:17',1,'crm','edit','/crm-quotes/edit/','127.0.0.1','CrmForm','update',6,NULL,NULL),(321,'2014-04-14 14:22:23',1,'crm','generateinvoice','/crm-forms/generateinvoice/6','127.0.0.1','CrmForm','insert',7,NULL,NULL),(322,'2014-04-14 14:22:23',1,'crm','generateinvoice','/crm-forms/generateinvoice/6','127.0.0.1','ObjectIndex','insert',69,NULL,NULL),(323,'2014-04-14 14:22:23',1,'crm','generateinvoice','/crm-forms/generateinvoice/6','127.0.0.1','CrmInvoice','insert',1,NULL,NULL),(324,'2014-04-14 14:22:23',1,'crm','generateinvoice','/crm-forms/generateinvoice/6','127.0.0.1','ObjectModification','insert',55,NULL,NULL),(325,'2014-04-14 14:22:23',1,'crm','generateinvoice','/crm-forms/generateinvoice/6','127.0.0.1','TaskGroup','insert',4,NULL,NULL),(326,'2014-04-14 14:22:23',1,'crm','generateinvoice','/crm-forms/generateinvoice/6','127.0.0.1','TaskGroupNotify','insert',19,NULL,NULL),(327,'2014-04-14 14:22:23',1,'crm','generateinvoice','/crm-forms/generateinvoice/6','127.0.0.1','TaskGroupNotify','insert',20,NULL,NULL),(328,'2014-04-14 14:22:23',1,'crm','generateinvoice','/crm-forms/generateinvoice/6','127.0.0.1','TaskGroupNotify','insert',21,NULL,NULL),(329,'2014-04-14 14:22:23',1,'crm','generateinvoice','/crm-forms/generateinvoice/6','127.0.0.1','TaskGroupNotify','insert',22,NULL,NULL),(330,'2014-04-14 14:22:23',1,'crm','generateinvoice','/crm-forms/generateinvoice/6','127.0.0.1','TaskGroupNotify','insert',23,NULL,NULL),(331,'2014-04-14 14:22:23',1,'crm','generateinvoice','/crm-forms/generateinvoice/6','127.0.0.1','TaskGroupNotify','insert',24,NULL,NULL),(332,'2014-04-14 14:22:23',1,'crm','generateinvoice','/crm-forms/generateinvoice/6','127.0.0.1','TaskGroupMember','insert',4,NULL,NULL),(333,'2014-04-14 14:22:23',1,'crm','generateinvoice','/crm-forms/generateinvoice/6','127.0.0.1','ObjectModification','insert',56,NULL,NULL),(334,'2014-04-14 14:22:23',1,'crm','generateinvoice','/crm-forms/generateinvoice/6','127.0.0.1','ObjectIndex','insert',70,NULL,NULL),(335,'2014-04-14 14:22:23',1,'crm','generateinvoice','/crm-forms/generateinvoice/6','127.0.0.1','Task','insert',52,NULL,NULL),(336,'2014-04-14 14:22:23',1,'crm','generateinvoice','/crm-forms/generateinvoice/6','127.0.0.1','TaskComment','insert',58,NULL,NULL),(337,'2014-04-14 14:22:23',1,'crm','generateinvoice','/crm-forms/generateinvoice/6','127.0.0.1','ObjectIndex','update',69,NULL,NULL),(338,'2014-04-14 14:22:23',1,'crm','generateinvoice','/crm-forms/generateinvoice/6','127.0.0.1','CrmInvoice','update',1,NULL,NULL),(339,'2014-04-14 14:22:23',1,'crm','generateinvoice','/crm-forms/generateinvoice/6','127.0.0.1','CrmForm','update',7,NULL,NULL),(340,'2014-04-14 14:22:23',1,'crm','generateinvoice','/crm-forms/generateinvoice/6','127.0.0.1','CrmForm','update',7,NULL,NULL),(341,'2014-04-14 14:22:37',1,'crm','delete','/crm-invoices/delete/1','127.0.0.1','ObjectIndex','update',69,NULL,NULL),(342,'2014-04-14 14:22:37',1,'crm','delete','/crm-invoices/delete/1','127.0.0.1','CrmInvoice','update',1,NULL,NULL),(343,'2014-04-14 14:22:37',1,'crm','delete','/crm-invoices/delete/1','127.0.0.1','ObjectIndex','delete',69,NULL,NULL),(344,'2014-04-14 14:22:37',1,'crm','delete','/crm-invoices/delete/1','127.0.0.1','CrmInvoice','delete',1,NULL,NULL),(345,'2014-04-14 14:22:37',1,'crm','delete','/crm-invoices/delete/1','127.0.0.1','CrmForm','update',7,NULL,NULL),(346,'2014-04-14 14:22:37',1,'crm','delete','/crm-invoices/delete/1','127.0.0.1','CrmForm','update',7,NULL,NULL),(347,'2014-04-14 14:22:37',1,'crm','delete','/crm-invoices/delete/1','127.0.0.1','CrmForm','delete',7,NULL,NULL),(348,'2014-04-14 14:22:53',1,'crm','edit','/crm-invoices/edit/','127.0.0.1','CrmForm','insert',8,NULL,NULL),(349,'2014-04-14 14:22:54',1,'crm','edit','/crm-invoices/edit/','127.0.0.1','ObjectIndex','insert',71,NULL,NULL),(350,'2014-04-14 14:22:54',1,'crm','edit','/crm-invoices/edit/','127.0.0.1','CrmInvoice','insert',2,NULL,NULL),(351,'2014-04-14 14:22:54',1,'crm','edit','/crm-invoices/edit/','127.0.0.1','ObjectModification','insert',57,NULL,NULL),(352,'2014-04-14 14:22:54',1,'crm','edit','/crm-invoices/edit/','127.0.0.1','ObjectIndex','insert',72,NULL,NULL),(353,'2014-04-14 14:22:54',1,'crm','edit','/crm-invoices/edit/','127.0.0.1','Task','insert',53,NULL,NULL),(354,'2014-04-14 14:22:54',1,'crm','edit','/crm-invoices/edit/','127.0.0.1','TaskComment','insert',59,NULL,NULL),(355,'2014-04-14 14:22:54',1,'crm','edit','/crm-invoices/edit/','127.0.0.1','ObjectIndex','update',71,NULL,NULL),(356,'2014-04-14 14:22:54',1,'crm','edit','/crm-invoices/edit/','127.0.0.1','CrmInvoice','update',2,NULL,NULL),(357,'2014-04-14 14:22:54',1,'crm','edit','/crm-invoices/edit/','127.0.0.1','CrmForm','update',8,NULL,NULL),(358,'2014-04-14 14:22:54',1,'crm','edit','/crm-invoices/edit/','127.0.0.1','CrmForm','update',8,NULL,NULL),(359,'2014-04-14 14:24:34',1,'crm','edit','/crm-projects/edit/','127.0.0.1','ObjectIndex','insert',73,NULL,NULL),(360,'2014-04-14 14:24:34',1,'crm','edit','/crm-projects/edit/','127.0.0.1','CrmProject','insert',1,NULL,NULL),(361,'2014-04-14 14:24:51',1,'crm','editmember','/crm-projects/editmember/1/','127.0.0.1','CrmProjectMember','insert',1,NULL,NULL),(362,'2014-04-14 14:30:12',1,'crm','addtaskgroup','/crm-projects/addtaskgroup/1','127.0.0.1','ObjectModification','insert',58,NULL,NULL),(363,'2014-04-14 14:30:12',1,'crm','addtaskgroup','/crm-projects/addtaskgroup/1','127.0.0.1','TaskGroup','insert',5,NULL,NULL),(364,'2014-04-14 14:30:12',1,'crm','addtaskgroup','/crm-projects/addtaskgroup/1','127.0.0.1','TaskGroupNotify','insert',25,NULL,NULL),(365,'2014-04-14 14:30:12',1,'crm','addtaskgroup','/crm-projects/addtaskgroup/1','127.0.0.1','TaskGroupNotify','insert',26,NULL,NULL),(366,'2014-04-14 14:30:12',1,'crm','addtaskgroup','/crm-projects/addtaskgroup/1','127.0.0.1','TaskGroupNotify','insert',27,NULL,NULL),(367,'2014-04-14 14:30:12',1,'crm','addtaskgroup','/crm-projects/addtaskgroup/1','127.0.0.1','TaskGroupNotify','insert',28,NULL,NULL),(368,'2014-04-14 14:30:12',1,'crm','addtaskgroup','/crm-projects/addtaskgroup/1','127.0.0.1','TaskGroupNotify','insert',29,NULL,NULL),(369,'2014-04-14 14:30:12',1,'crm','addtaskgroup','/crm-projects/addtaskgroup/1','127.0.0.1','TaskGroupNotify','insert',30,NULL,NULL),(370,'2014-04-14 14:30:12',1,'crm','addtaskgroup','/crm-projects/addtaskgroup/1','127.0.0.1','TaskGroupMember','insert',5,NULL,NULL),(371,'2014-04-14 14:30:12',1,'crm','addtaskgroup','/crm-projects/addtaskgroup/1','127.0.0.1','CrmProjectTaskgroup','insert',1,NULL,NULL),(372,'2014-04-14 14:45:14',1,'crm','edit','/crm-expenses/edit/','127.0.0.1','ObjectIndex','insert',74,NULL,NULL),(373,'2014-04-14 14:45:14',1,'crm','edit','/crm-expenses/edit/','127.0.0.1','CrmExpense','insert',1,NULL,NULL),(374,'2014-04-14 14:45:14',1,'crm','edit','/crm-expenses/edit/','127.0.0.1','ObjectModification','insert',59,NULL,NULL),(375,'2014-04-14 14:45:14',1,'crm','edit','/crm-expenses/edit/','127.0.0.1','TaskGroup','insert',6,NULL,NULL),(376,'2014-04-14 14:45:14',1,'crm','edit','/crm-expenses/edit/','127.0.0.1','TaskGroupNotify','insert',31,NULL,NULL),(377,'2014-04-14 14:45:14',1,'crm','edit','/crm-expenses/edit/','127.0.0.1','TaskGroupNotify','insert',32,NULL,NULL),(378,'2014-04-14 14:45:14',1,'crm','edit','/crm-expenses/edit/','127.0.0.1','TaskGroupNotify','insert',33,NULL,NULL),(379,'2014-04-14 14:45:14',1,'crm','edit','/crm-expenses/edit/','127.0.0.1','TaskGroupNotify','insert',34,NULL,NULL),(380,'2014-04-14 14:45:14',1,'crm','edit','/crm-expenses/edit/','127.0.0.1','TaskGroupNotify','insert',35,NULL,NULL),(381,'2014-04-14 14:45:14',1,'crm','edit','/crm-expenses/edit/','127.0.0.1','TaskGroupNotify','insert',36,NULL,NULL),(382,'2014-04-14 14:45:14',1,'crm','edit','/crm-expenses/edit/','127.0.0.1','TaskGroupMember','insert',6,NULL,NULL),(383,'2014-04-14 14:45:14',1,'crm','edit','/crm-expenses/edit/','127.0.0.1','ObjectModification','insert',60,NULL,NULL),(384,'2014-04-14 14:45:14',1,'crm','edit','/crm-expenses/edit/','127.0.0.1','ObjectIndex','insert',75,NULL,NULL),(385,'2014-04-14 14:45:14',1,'crm','edit','/crm-expenses/edit/','127.0.0.1','Task','insert',54,NULL,NULL),(386,'2014-04-14 14:45:14',1,'crm','edit','/crm-expenses/edit/','127.0.0.1','TaskComment','insert',60,NULL,NULL),(387,'2014-04-14 14:45:14',1,'crm','edit','/crm-expenses/edit/','127.0.0.1','ObjectIndex','update',74,NULL,NULL),(388,'2014-04-14 14:45:14',1,'crm','edit','/crm-expenses/edit/','127.0.0.1','CrmExpense','update',1,NULL,NULL),(389,'2014-04-14 14:59:03',1,'main','addwidget','/main/addwidget/channels','127.0.0.1','WidgetConfig','insert',1,NULL,NULL),(390,'2014-04-14 14:59:14',1,'main','removewidget','/main/removewidget/channels/1','127.0.0.1','WidgetConfig','update',1,NULL,NULL),(391,'2014-04-14 14:59:14',1,'main','removewidget','/main/removewidget/channels/1','127.0.0.1','WidgetConfig','delete',1,NULL,NULL),(392,'2014-04-23 14:44:48',1,'main','addwidget','/main/addwidget/crm','127.0.0.1','WidgetConfig','insert',2,NULL,NULL),(393,'2014-04-23 15:16:13',1,'crm','edit','/crm-accounts/edit/','127.0.0.1','ObjectIndex','insert',76,NULL,NULL),(394,'2014-04-23 15:16:13',1,'crm','edit','/crm-accounts/edit/','127.0.0.1','CrmAccount','insert',2,NULL,NULL),(395,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',77,NULL,NULL),(396,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',3,NULL,NULL),(397,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',78,NULL,NULL),(398,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',4,NULL,NULL),(399,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',79,NULL,NULL),(400,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',5,NULL,NULL),(401,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',80,NULL,NULL),(402,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',6,NULL,NULL),(403,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',81,NULL,NULL),(404,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',7,NULL,NULL),(405,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',82,NULL,NULL),(406,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',8,NULL,NULL),(407,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',83,NULL,NULL),(408,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',9,NULL,NULL),(409,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',84,NULL,NULL),(410,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',10,NULL,NULL),(411,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',85,NULL,NULL),(412,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',11,NULL,NULL),(413,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',86,NULL,NULL),(414,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',12,NULL,NULL),(415,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',87,NULL,NULL),(416,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',13,NULL,NULL),(417,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',88,NULL,NULL),(418,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',14,NULL,NULL),(419,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',89,NULL,NULL),(420,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',15,NULL,NULL),(421,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',90,NULL,NULL),(422,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',16,NULL,NULL),(423,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',91,NULL,NULL),(424,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',17,NULL,NULL),(425,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',92,NULL,NULL),(426,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',18,NULL,NULL),(427,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',93,NULL,NULL),(428,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',19,NULL,NULL),(429,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',94,NULL,NULL),(430,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',20,NULL,NULL),(431,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',95,NULL,NULL),(432,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',21,NULL,NULL),(433,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',96,NULL,NULL),(434,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',22,NULL,NULL),(435,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',97,NULL,NULL),(436,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',23,NULL,NULL),(437,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',98,NULL,NULL),(438,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',24,NULL,NULL),(439,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',99,NULL,NULL),(440,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',25,NULL,NULL),(441,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',100,NULL,NULL),(442,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',26,NULL,NULL),(443,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',101,NULL,NULL),(444,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',27,NULL,NULL),(445,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',102,NULL,NULL),(446,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',28,NULL,NULL),(447,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',103,NULL,NULL),(448,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',29,NULL,NULL),(449,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',104,NULL,NULL),(450,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',30,NULL,NULL),(451,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',105,NULL,NULL),(452,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',31,NULL,NULL),(453,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',106,NULL,NULL),(454,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',32,NULL,NULL),(455,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',107,NULL,NULL),(456,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',33,NULL,NULL),(457,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',108,NULL,NULL),(458,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',34,NULL,NULL),(459,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',109,NULL,NULL),(460,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',35,NULL,NULL),(461,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',110,NULL,NULL),(462,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',36,NULL,NULL),(463,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',111,NULL,NULL),(464,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',37,NULL,NULL),(465,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',112,NULL,NULL),(466,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',38,NULL,NULL),(467,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',113,NULL,NULL),(468,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',39,NULL,NULL),(469,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',114,NULL,NULL),(470,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',40,NULL,NULL),(471,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',115,NULL,NULL),(472,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',41,NULL,NULL),(473,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',116,NULL,NULL),(474,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',42,NULL,NULL),(475,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',117,NULL,NULL),(476,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',43,NULL,NULL),(477,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',118,NULL,NULL),(478,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',44,NULL,NULL),(479,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',119,NULL,NULL),(480,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',45,NULL,NULL),(481,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',120,NULL,NULL),(482,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',46,NULL,NULL),(483,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',121,NULL,NULL),(484,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',47,NULL,NULL),(485,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',122,NULL,NULL),(486,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',48,NULL,NULL),(487,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',123,NULL,NULL),(488,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',49,NULL,NULL),(489,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',124,NULL,NULL),(490,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',50,NULL,NULL),(491,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',125,NULL,NULL),(492,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',51,NULL,NULL),(493,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',126,NULL,NULL),(494,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',52,NULL,NULL),(495,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',127,NULL,NULL),(496,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',53,NULL,NULL),(497,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',128,NULL,NULL),(498,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',54,NULL,NULL),(499,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',129,NULL,NULL),(500,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',55,NULL,NULL),(501,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',130,NULL,NULL),(502,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',56,NULL,NULL),(503,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',131,NULL,NULL),(504,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',57,NULL,NULL),(505,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',132,NULL,NULL),(506,'2014-04-23 15:32:55',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',58,NULL,NULL),(507,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',133,NULL,NULL),(508,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',59,NULL,NULL),(509,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',134,NULL,NULL),(510,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',60,NULL,NULL),(511,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',135,NULL,NULL),(512,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',61,NULL,NULL),(513,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',136,NULL,NULL),(514,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',62,NULL,NULL),(515,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',137,NULL,NULL),(516,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',63,NULL,NULL),(517,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',138,NULL,NULL),(518,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',64,NULL,NULL),(519,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',139,NULL,NULL),(520,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',65,NULL,NULL),(521,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',140,NULL,NULL),(522,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',66,NULL,NULL),(523,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',141,NULL,NULL),(524,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',67,NULL,NULL),(525,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',142,NULL,NULL),(526,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',68,NULL,NULL),(527,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',143,NULL,NULL),(528,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',69,NULL,NULL),(529,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',144,NULL,NULL),(530,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',70,NULL,NULL),(531,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',145,NULL,NULL),(532,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',71,NULL,NULL),(533,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',146,NULL,NULL),(534,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',72,NULL,NULL),(535,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',147,NULL,NULL),(536,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',73,NULL,NULL),(537,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',148,NULL,NULL),(538,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',74,NULL,NULL),(539,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',149,NULL,NULL),(540,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',75,NULL,NULL),(541,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',150,NULL,NULL),(542,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',76,NULL,NULL),(543,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',151,NULL,NULL),(544,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',77,NULL,NULL),(545,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',152,NULL,NULL),(546,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',78,NULL,NULL),(547,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',153,NULL,NULL),(548,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',79,NULL,NULL),(549,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',154,NULL,NULL),(550,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',80,NULL,NULL),(551,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',155,NULL,NULL),(552,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',81,NULL,NULL),(553,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',156,NULL,NULL),(554,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',82,NULL,NULL),(555,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',157,NULL,NULL),(556,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',83,NULL,NULL),(557,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',158,NULL,NULL),(558,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',84,NULL,NULL),(559,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',159,NULL,NULL),(560,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',85,NULL,NULL),(561,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',160,NULL,NULL),(562,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',86,NULL,NULL),(563,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',161,NULL,NULL),(564,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',87,NULL,NULL),(565,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',162,NULL,NULL),(566,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',88,NULL,NULL),(567,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',163,NULL,NULL),(568,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',89,NULL,NULL),(569,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',164,NULL,NULL),(570,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',90,NULL,NULL),(571,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',165,NULL,NULL),(572,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',91,NULL,NULL),(573,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',166,NULL,NULL),(574,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',92,NULL,NULL),(575,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',167,NULL,NULL),(576,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',93,NULL,NULL),(577,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',168,NULL,NULL),(578,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',94,NULL,NULL),(579,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',169,NULL,NULL),(580,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',95,NULL,NULL),(581,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',170,NULL,NULL),(582,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',96,NULL,NULL),(583,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',171,NULL,NULL),(584,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',97,NULL,NULL),(585,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',172,NULL,NULL),(586,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',98,NULL,NULL),(587,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',173,NULL,NULL),(588,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',99,NULL,NULL),(589,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',174,NULL,NULL),(590,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',100,NULL,NULL),(591,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',175,NULL,NULL),(592,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',101,NULL,NULL),(593,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',176,NULL,NULL),(594,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',102,NULL,NULL),(595,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',177,NULL,NULL),(596,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',103,NULL,NULL),(597,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',178,NULL,NULL),(598,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',104,NULL,NULL),(599,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',179,NULL,NULL),(600,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',105,NULL,NULL),(601,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',180,NULL,NULL),(602,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',106,NULL,NULL),(603,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',181,NULL,NULL),(604,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',107,NULL,NULL),(605,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',182,NULL,NULL),(606,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',108,NULL,NULL),(607,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',183,NULL,NULL),(608,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',109,NULL,NULL),(609,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',184,NULL,NULL),(610,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',110,NULL,NULL),(611,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',185,NULL,NULL),(612,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',111,NULL,NULL),(613,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',186,NULL,NULL),(614,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',112,NULL,NULL),(615,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',187,NULL,NULL),(616,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',113,NULL,NULL),(617,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',188,NULL,NULL),(618,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',114,NULL,NULL),(619,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',189,NULL,NULL),(620,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',115,NULL,NULL),(621,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',190,NULL,NULL),(622,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',116,NULL,NULL),(623,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',191,NULL,NULL),(624,'2014-04-23 15:32:56',1,'crm','import','/crm-admin/import','127.0.0.1','CrmAccount','insert',117,NULL,NULL),(625,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',3,NULL,NULL),(626,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',192,NULL,NULL),(627,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',2,NULL,NULL),(628,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',4,NULL,NULL),(629,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',193,NULL,NULL),(630,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',3,NULL,NULL),(631,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',5,NULL,NULL),(632,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',194,NULL,NULL),(633,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',4,NULL,NULL),(634,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',6,NULL,NULL),(635,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',195,NULL,NULL),(636,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',5,NULL,NULL),(637,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',7,NULL,NULL),(638,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',196,NULL,NULL),(639,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',6,NULL,NULL),(640,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',8,NULL,NULL),(641,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',197,NULL,NULL),(642,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',7,NULL,NULL),(643,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',9,NULL,NULL),(644,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',198,NULL,NULL),(645,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',8,NULL,NULL),(646,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',10,NULL,NULL),(647,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',199,NULL,NULL),(648,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',9,NULL,NULL),(649,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',11,NULL,NULL),(650,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',200,NULL,NULL),(651,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',10,NULL,NULL),(652,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',12,NULL,NULL),(653,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',201,NULL,NULL),(654,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',11,NULL,NULL),(655,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',13,NULL,NULL),(656,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',202,NULL,NULL),(657,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',12,NULL,NULL),(658,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',14,NULL,NULL),(659,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',203,NULL,NULL),(660,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',13,NULL,NULL),(661,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',15,NULL,NULL),(662,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',204,NULL,NULL),(663,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',14,NULL,NULL),(664,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',16,NULL,NULL),(665,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',205,NULL,NULL),(666,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',15,NULL,NULL),(667,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',17,NULL,NULL),(668,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',206,NULL,NULL),(669,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',16,NULL,NULL),(670,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',18,NULL,NULL),(671,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',207,NULL,NULL),(672,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',17,NULL,NULL),(673,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',19,NULL,NULL),(674,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',208,NULL,NULL),(675,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',18,NULL,NULL),(676,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',20,NULL,NULL),(677,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',209,NULL,NULL),(678,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',19,NULL,NULL),(679,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',21,NULL,NULL),(680,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',210,NULL,NULL),(681,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',20,NULL,NULL),(682,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',22,NULL,NULL),(683,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',211,NULL,NULL),(684,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',21,NULL,NULL),(685,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',23,NULL,NULL),(686,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',212,NULL,NULL),(687,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',22,NULL,NULL),(688,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',24,NULL,NULL),(689,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',213,NULL,NULL),(690,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',23,NULL,NULL),(691,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',25,NULL,NULL),(692,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',214,NULL,NULL),(693,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',24,NULL,NULL),(694,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',26,NULL,NULL),(695,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',215,NULL,NULL),(696,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',25,NULL,NULL),(697,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',27,NULL,NULL),(698,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',216,NULL,NULL),(699,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',26,NULL,NULL),(700,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',28,NULL,NULL),(701,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',217,NULL,NULL),(702,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',27,NULL,NULL),(703,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',29,NULL,NULL),(704,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',218,NULL,NULL),(705,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',28,NULL,NULL),(706,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',30,NULL,NULL),(707,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',219,NULL,NULL),(708,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',29,NULL,NULL),(709,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',31,NULL,NULL),(710,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',220,NULL,NULL),(711,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',30,NULL,NULL),(712,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',32,NULL,NULL),(713,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',221,NULL,NULL),(714,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',31,NULL,NULL),(715,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',33,NULL,NULL),(716,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',222,NULL,NULL),(717,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',32,NULL,NULL),(718,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',34,NULL,NULL),(719,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',223,NULL,NULL),(720,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',33,NULL,NULL),(721,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',35,NULL,NULL),(722,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',224,NULL,NULL),(723,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',34,NULL,NULL),(724,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',36,NULL,NULL),(725,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',225,NULL,NULL),(726,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',35,NULL,NULL),(727,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',37,NULL,NULL),(728,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',226,NULL,NULL),(729,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',36,NULL,NULL),(730,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',38,NULL,NULL),(731,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',227,NULL,NULL),(732,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',37,NULL,NULL),(733,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',39,NULL,NULL),(734,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',228,NULL,NULL),(735,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',38,NULL,NULL),(736,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',40,NULL,NULL),(737,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',229,NULL,NULL),(738,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',39,NULL,NULL),(739,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',41,NULL,NULL),(740,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',230,NULL,NULL),(741,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',40,NULL,NULL),(742,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',42,NULL,NULL),(743,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',231,NULL,NULL),(744,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',41,NULL,NULL),(745,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',43,NULL,NULL),(746,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',232,NULL,NULL),(747,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',42,NULL,NULL),(748,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',44,NULL,NULL),(749,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',233,NULL,NULL),(750,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',43,NULL,NULL),(751,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',45,NULL,NULL),(752,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',234,NULL,NULL),(753,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',44,NULL,NULL),(754,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',46,NULL,NULL),(755,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',235,NULL,NULL),(756,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',45,NULL,NULL),(757,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',47,NULL,NULL),(758,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',236,NULL,NULL),(759,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',46,NULL,NULL),(760,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',48,NULL,NULL),(761,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',237,NULL,NULL),(762,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',47,NULL,NULL),(763,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',49,NULL,NULL),(764,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',238,NULL,NULL),(765,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',48,NULL,NULL),(766,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',50,NULL,NULL),(767,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',239,NULL,NULL),(768,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',49,NULL,NULL),(769,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',51,NULL,NULL),(770,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',240,NULL,NULL),(771,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',50,NULL,NULL),(772,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',52,NULL,NULL),(773,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',241,NULL,NULL),(774,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',51,NULL,NULL),(775,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',53,NULL,NULL),(776,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',242,NULL,NULL),(777,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',52,NULL,NULL),(778,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',54,NULL,NULL),(779,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',243,NULL,NULL),(780,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',53,NULL,NULL),(781,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',55,NULL,NULL),(782,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',244,NULL,NULL),(783,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',54,NULL,NULL),(784,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',56,NULL,NULL),(785,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',245,NULL,NULL),(786,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',55,NULL,NULL),(787,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',57,NULL,NULL),(788,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',246,NULL,NULL),(789,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',56,NULL,NULL),(790,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',58,NULL,NULL),(791,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',247,NULL,NULL),(792,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',57,NULL,NULL),(793,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',59,NULL,NULL),(794,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',248,NULL,NULL),(795,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',58,NULL,NULL),(796,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',60,NULL,NULL),(797,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',249,NULL,NULL),(798,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',59,NULL,NULL),(799,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',61,NULL,NULL),(800,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',250,NULL,NULL),(801,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',60,NULL,NULL),(802,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',62,NULL,NULL),(803,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',251,NULL,NULL),(804,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',61,NULL,NULL),(805,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',63,NULL,NULL),(806,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',252,NULL,NULL),(807,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',62,NULL,NULL),(808,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',64,NULL,NULL),(809,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',253,NULL,NULL),(810,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',63,NULL,NULL),(811,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',65,NULL,NULL),(812,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',254,NULL,NULL),(813,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',64,NULL,NULL),(814,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',66,NULL,NULL),(815,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',255,NULL,NULL),(816,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',65,NULL,NULL),(817,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',67,NULL,NULL),(818,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',256,NULL,NULL),(819,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',66,NULL,NULL),(820,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',68,NULL,NULL),(821,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',257,NULL,NULL),(822,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',67,NULL,NULL),(823,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',69,NULL,NULL),(824,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',258,NULL,NULL),(825,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',68,NULL,NULL),(826,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',70,NULL,NULL),(827,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',259,NULL,NULL),(828,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',69,NULL,NULL),(829,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',71,NULL,NULL),(830,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',260,NULL,NULL),(831,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',70,NULL,NULL),(832,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',72,NULL,NULL),(833,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',261,NULL,NULL),(834,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',71,NULL,NULL),(835,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',73,NULL,NULL),(836,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',262,NULL,NULL),(837,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',72,NULL,NULL),(838,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',74,NULL,NULL),(839,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',263,NULL,NULL),(840,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',73,NULL,NULL),(841,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',75,NULL,NULL),(842,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',264,NULL,NULL),(843,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',74,NULL,NULL),(844,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',76,NULL,NULL),(845,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',265,NULL,NULL),(846,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',75,NULL,NULL),(847,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',77,NULL,NULL),(848,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',266,NULL,NULL),(849,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',76,NULL,NULL),(850,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',78,NULL,NULL),(851,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',267,NULL,NULL),(852,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',77,NULL,NULL),(853,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',79,NULL,NULL),(854,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',268,NULL,NULL),(855,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',78,NULL,NULL),(856,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',80,NULL,NULL),(857,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',269,NULL,NULL),(858,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',79,NULL,NULL),(859,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',81,NULL,NULL),(860,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',270,NULL,NULL),(861,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',80,NULL,NULL),(862,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',82,NULL,NULL),(863,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',271,NULL,NULL),(864,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',81,NULL,NULL),(865,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',83,NULL,NULL),(866,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',272,NULL,NULL),(867,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',82,NULL,NULL),(868,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',84,NULL,NULL),(869,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',273,NULL,NULL),(870,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',83,NULL,NULL),(871,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',85,NULL,NULL),(872,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',274,NULL,NULL),(873,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',84,NULL,NULL),(874,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',86,NULL,NULL),(875,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',275,NULL,NULL),(876,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',85,NULL,NULL),(877,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',87,NULL,NULL),(878,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',276,NULL,NULL),(879,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',86,NULL,NULL),(880,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',88,NULL,NULL),(881,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',277,NULL,NULL),(882,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',87,NULL,NULL),(883,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',89,NULL,NULL),(884,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',278,NULL,NULL),(885,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',88,NULL,NULL),(886,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',90,NULL,NULL),(887,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',279,NULL,NULL),(888,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',89,NULL,NULL),(889,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',91,NULL,NULL),(890,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',280,NULL,NULL),(891,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',90,NULL,NULL),(892,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',92,NULL,NULL),(893,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',281,NULL,NULL),(894,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',91,NULL,NULL),(895,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',93,NULL,NULL),(896,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',282,NULL,NULL),(897,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',92,NULL,NULL),(898,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',94,NULL,NULL),(899,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',283,NULL,NULL),(900,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',93,NULL,NULL),(901,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',95,NULL,NULL),(902,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',284,NULL,NULL),(903,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',94,NULL,NULL),(904,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',96,NULL,NULL),(905,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',285,NULL,NULL),(906,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',95,NULL,NULL),(907,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',97,NULL,NULL),(908,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',286,NULL,NULL),(909,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',96,NULL,NULL),(910,'2014-04-23 16:46:58',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',98,NULL,NULL),(911,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',287,NULL,NULL),(912,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',97,NULL,NULL),(913,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',99,NULL,NULL),(914,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',288,NULL,NULL),(915,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',98,NULL,NULL),(916,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',100,NULL,NULL),(917,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',289,NULL,NULL),(918,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',99,NULL,NULL),(919,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',101,NULL,NULL),(920,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',290,NULL,NULL),(921,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',100,NULL,NULL),(922,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',102,NULL,NULL),(923,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',291,NULL,NULL),(924,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',101,NULL,NULL),(925,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',103,NULL,NULL),(926,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',292,NULL,NULL),(927,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',102,NULL,NULL),(928,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',104,NULL,NULL),(929,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',293,NULL,NULL),(930,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',103,NULL,NULL),(931,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',105,NULL,NULL),(932,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',294,NULL,NULL),(933,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',104,NULL,NULL),(934,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',106,NULL,NULL),(935,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',295,NULL,NULL),(936,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',105,NULL,NULL),(937,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',107,NULL,NULL),(938,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',296,NULL,NULL),(939,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',106,NULL,NULL),(940,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',108,NULL,NULL),(941,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',297,NULL,NULL),(942,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',107,NULL,NULL),(943,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',109,NULL,NULL),(944,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',298,NULL,NULL),(945,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',108,NULL,NULL),(946,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',110,NULL,NULL),(947,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',299,NULL,NULL),(948,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',109,NULL,NULL),(949,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',111,NULL,NULL),(950,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',300,NULL,NULL),(951,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',110,NULL,NULL),(952,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',112,NULL,NULL),(953,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',301,NULL,NULL),(954,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',111,NULL,NULL),(955,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',113,NULL,NULL),(956,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',302,NULL,NULL),(957,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',112,NULL,NULL),(958,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',114,NULL,NULL),(959,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',303,NULL,NULL),(960,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',113,NULL,NULL),(961,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',115,NULL,NULL),(962,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',304,NULL,NULL),(963,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',114,NULL,NULL),(964,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',116,NULL,NULL),(965,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',305,NULL,NULL),(966,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',115,NULL,NULL),(967,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',117,NULL,NULL),(968,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',306,NULL,NULL),(969,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',116,NULL,NULL),(970,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',118,NULL,NULL),(971,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',307,NULL,NULL),(972,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',117,NULL,NULL),(973,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',119,NULL,NULL),(974,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',308,NULL,NULL),(975,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',118,NULL,NULL),(976,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',120,NULL,NULL),(977,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',309,NULL,NULL),(978,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',119,NULL,NULL),(979,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',121,NULL,NULL),(980,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',310,NULL,NULL),(981,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',120,NULL,NULL),(982,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',122,NULL,NULL),(983,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',311,NULL,NULL),(984,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',121,NULL,NULL),(985,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',123,NULL,NULL),(986,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',312,NULL,NULL),(987,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',122,NULL,NULL),(988,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',124,NULL,NULL),(989,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',313,NULL,NULL),(990,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',123,NULL,NULL),(991,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',125,NULL,NULL),(992,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',314,NULL,NULL),(993,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',124,NULL,NULL),(994,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',126,NULL,NULL),(995,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',315,NULL,NULL),(996,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',125,NULL,NULL),(997,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',127,NULL,NULL),(998,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',316,NULL,NULL),(999,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',126,NULL,NULL),(1000,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',128,NULL,NULL),(1001,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',317,NULL,NULL),(1002,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',127,NULL,NULL),(1003,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',129,NULL,NULL),(1004,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',318,NULL,NULL),(1005,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',128,NULL,NULL),(1006,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',130,NULL,NULL),(1007,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',319,NULL,NULL),(1008,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',129,NULL,NULL),(1009,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',131,NULL,NULL),(1010,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',320,NULL,NULL),(1011,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',130,NULL,NULL),(1012,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',132,NULL,NULL),(1013,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',321,NULL,NULL),(1014,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',131,NULL,NULL),(1015,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',133,NULL,NULL),(1016,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',322,NULL,NULL),(1017,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',132,NULL,NULL),(1018,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',134,NULL,NULL),(1019,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',323,NULL,NULL),(1020,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',133,NULL,NULL),(1021,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',135,NULL,NULL),(1022,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',324,NULL,NULL),(1023,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',134,NULL,NULL),(1024,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',136,NULL,NULL),(1025,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',325,NULL,NULL),(1026,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',135,NULL,NULL),(1027,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',137,NULL,NULL),(1028,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',326,NULL,NULL),(1029,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',136,NULL,NULL),(1030,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',138,NULL,NULL),(1031,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',327,NULL,NULL),(1032,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',137,NULL,NULL),(1033,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',139,NULL,NULL),(1034,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',328,NULL,NULL),(1035,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',138,NULL,NULL),(1036,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',140,NULL,NULL),(1037,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',329,NULL,NULL),(1038,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',139,NULL,NULL),(1039,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',141,NULL,NULL),(1040,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',330,NULL,NULL),(1041,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',140,NULL,NULL),(1042,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',142,NULL,NULL),(1043,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',331,NULL,NULL),(1044,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',141,NULL,NULL),(1045,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',143,NULL,NULL),(1046,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',332,NULL,NULL),(1047,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',142,NULL,NULL),(1048,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',144,NULL,NULL),(1049,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',333,NULL,NULL),(1050,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',143,NULL,NULL),(1051,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',145,NULL,NULL),(1052,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',334,NULL,NULL),(1053,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',144,NULL,NULL),(1054,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',146,NULL,NULL),(1055,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',335,NULL,NULL),(1056,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',145,NULL,NULL),(1057,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',147,NULL,NULL),(1058,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',336,NULL,NULL),(1059,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',146,NULL,NULL),(1060,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',148,NULL,NULL),(1061,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',337,NULL,NULL),(1062,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',147,NULL,NULL),(1063,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',149,NULL,NULL),(1064,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',338,NULL,NULL),(1065,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',148,NULL,NULL),(1066,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','Contact','insert',150,NULL,NULL),(1067,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','ObjectIndex','insert',339,NULL,NULL),(1068,'2014-04-23 16:46:59',1,'crm','import','/crm-admin/import','127.0.0.1','CrmContact','insert',149,NULL,NULL),(1069,'2014-04-23 16:47:18',1,'crm','edit','/crm-accounts/edit/113','127.0.0.1','ObjectIndex','update',187,NULL,NULL),(1070,'2014-04-23 16:47:19',1,'crm','edit','/crm-accounts/edit/113','127.0.0.1','CrmAccount','update',113,NULL,NULL),(1071,'2014-04-23 17:00:10',1,'crm','edit','/crm-accounts/edit/52','127.0.0.1','ObjectIndex','update',126,NULL,NULL),(1072,'2014-04-23 17:00:10',1,'crm','edit','/crm-accounts/edit/52','127.0.0.1','CrmAccount','update',52,NULL,NULL),(1073,'2014-04-23 17:01:36',1,'crm','edit','/crm-accounts/edit/52','127.0.0.1','ObjectIndex','update',126,NULL,NULL),(1074,'2014-04-23 17:01:36',1,'crm','edit','/crm-accounts/edit/52','127.0.0.1','CrmAccount','update',52,NULL,NULL),(1075,'2014-04-23 17:05:01',1,'crm','edit','/crm-accounts/edit/52','127.0.0.1','ObjectIndex','update',126,NULL,NULL),(1076,'2014-04-23 17:05:01',1,'crm','edit','/crm-accounts/edit/52','127.0.0.1','CrmAccount','update',52,NULL,NULL),(1077,'2014-04-23 17:06:20',1,'crm','edit','/crm-accounts/edit/52','127.0.0.1','ObjectIndex','update',126,NULL,NULL),(1078,'2014-04-23 17:06:20',1,'crm','edit','/crm-accounts/edit/52','127.0.0.1','CrmAccount','update',52,NULL,NULL);
/*!40000 ALTER TABLE `audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel`
--

DROP TABLE IF EXISTS `channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notify_user_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notify_user_id` bigint(20) DEFAULT NULL,
  `do_processing` tinyint(1) NOT NULL DEFAULT '1',
  `creator_id` bigint(20) NOT NULL,
  `modifier_id` bigint(20) NOT NULL,
  `dt_created` datetime NOT NULL,
  `dt_modified` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel`
--

LOCK TABLES `channel` WRITE;
/*!40000 ALTER TABLE `channel` DISABLE KEYS */;
/*!40000 ALTER TABLE `channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel_email_option`
--

DROP TABLE IF EXISTS `channel_email_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel_email_option` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `channel_id` bigint(20) NOT NULL,
  `server` varchar(1024) COLLATE utf8_unicode_ci NOT NULL,
  `s_username` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `s_password` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `port` int(11) DEFAULT NULL,
  `use_auth` tinyint(4) NOT NULL DEFAULT '1',
  `folder` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `protocol` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `to_filter` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `from_filter` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subject_filter` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cc_filter` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `body_filter` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `post_read_action` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `post_read_parameter` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `creator_id` bigint(20) NOT NULL,
  `modifier_id` bigint(20) NOT NULL,
  `dt_created` datetime NOT NULL,
  `dt_modified` datetime NOT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_email_option`
--

LOCK TABLES `channel_email_option` WRITE;
/*!40000 ALTER TABLE `channel_email_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `channel_email_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel_message`
--

DROP TABLE IF EXISTS `channel_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel_message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `channel_id` bigint(20) NOT NULL,
  `message_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_processed` tinyint(1) NOT NULL DEFAULT '0',
  `creator_id` bigint(20) DEFAULT NULL,
  `modifier_id` bigint(20) DEFAULT NULL,
  `dt_created` datetime NOT NULL,
  `dt_modified` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_message`
--

LOCK TABLES `channel_message` WRITE;
/*!40000 ALTER TABLE `channel_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `channel_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel_message_status`
--

DROP TABLE IF EXISTS `channel_message_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel_message_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `message_id` bigint(20) NOT NULL,
  `processor_id` bigint(20) NOT NULL,
  `message` text COLLATE utf8_unicode_ci,
  `is_successful` tinyint(1) NOT NULL DEFAULT '0',
  `creator_id` bigint(20) DEFAULT NULL,
  `modifier_id` bigint(20) DEFAULT NULL,
  `dt_created` datetime NOT NULL,
  `dt_modified` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_message_status`
--

LOCK TABLES `channel_message_status` WRITE;
/*!40000 ALTER TABLE `channel_message_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `channel_message_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel_processor`
--

DROP TABLE IF EXISTS `channel_processor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel_processor` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `module` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `channel_id` bigint(20) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `settings` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `creator_id` bigint(20) NOT NULL,
  `modifier_id` bigint(20) NOT NULL,
  `dt_created` datetime NOT NULL,
  `dt_modified` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_processor`
--

LOCK TABLES `channel_processor` WRITE;
/*!40000 ALTER TABLE `channel_processor` DISABLE KEYS */;
/*!40000 ALTER TABLE `channel_processor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `obj_table` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `obj_id` bigint(20) DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_internal` tinyint(4) NOT NULL DEFAULT '0',
  `is_system` tinyint(4) NOT NULL DEFAULT '0',
  `creator_id` bigint(20) DEFAULT NULL,
  `dt_created` datetime DEFAULT NULL,
  `modifier_id` bigint(20) DEFAULT NULL,
  `dt_modified` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (1,'task',NULL,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(2,'task',NULL,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(3,'task',NULL,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(4,'task',1,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(5,'task',2,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(6,'task',3,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(7,'task',4,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(8,'task',5,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(9,'task',6,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(10,'task',7,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(11,'task',8,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(12,'task',9,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(13,'task',10,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(14,'task',11,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(15,'task',12,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(16,'task',13,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(17,'task',14,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(18,'task',15,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(19,'task',16,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(20,'task',17,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(21,'task',18,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(22,'task',19,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(23,'task',20,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(24,'task',21,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(25,'task',22,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(26,'task',23,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(27,'task',24,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(28,'task',25,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(29,'task',26,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(30,'task',27,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(31,'task',28,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(32,'task',29,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(33,'task',30,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(34,'task',31,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(35,'task',32,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(36,'task',33,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(37,'task',34,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(38,'task',35,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(39,'task',36,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(40,'task',37,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(41,'task',38,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(42,'task',39,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(43,'task',40,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(44,'task',41,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(45,'task',42,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(46,'task',43,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(47,'task',44,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(48,'task',45,'Task Created',0,0,NULL,NULL,NULL,NULL,0),(49,'task',39,'Comment&nbsp;',0,0,NULL,NULL,NULL,NULL,0),(50,'task',39,'Another comment',0,0,NULL,NULL,NULL,NULL,0),(51,'task',39,'Test&nbsp;',0,0,1,'2014-04-14 10:58:01',1,'2014-04-14 10:58:01',0),(52,'task',46,'Task Created',0,0,1,'2014-04-14 14:12:30',1,'2014-04-14 14:12:30',NULL),(53,'task',47,'Task Created',0,0,1,'2014-04-14 14:13:46',1,'2014-04-14 14:13:46',NULL),(54,'task',48,'Task Created',0,0,1,'2014-04-14 14:20:30',1,'2014-04-14 14:20:30',NULL),(55,'task',49,'Task Created',0,0,1,'2014-04-14 14:20:42',1,'2014-04-14 14:20:42',NULL),(56,'task',50,'Task Created',0,0,1,'2014-04-14 14:21:58',1,'2014-04-14 14:21:58',NULL),(57,'task',51,'Task Created',0,0,1,'2014-04-14 14:22:17',1,'2014-04-14 14:22:17',NULL),(58,'task',52,'Task Created',0,0,1,'2014-04-14 14:22:23',1,'2014-04-14 14:22:23',NULL),(59,'task',53,'Task Created',0,0,1,'2014-04-14 14:22:54',1,'2014-04-14 14:22:54',NULL),(60,'task',54,'Task Created',0,0,1,'2014-04-14 14:45:14',1,'2014-04-14 14:45:14',NULL);
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `othername` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `homephone` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `workphone` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priv_mobile` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `dt_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dt_modified` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `private_to_user_id` bigint(20) DEFAULT NULL,
  `creator_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` VALUES (1,'Administrator','Admin',NULL,NULL,'','','','','','admin@tripleacs.com',NULL,'2012-04-26 20:31:52','2014-04-07 12:21:44',0,NULL,NULL),(2,'Adam','Buckley',NULL,NULL,'0422185393','','','','','adam.buckley90@gmail.com',NULL,'2014-04-11 04:52:00','2014-04-11 14:52:00',0,NULL,1),(3,'Andrew','Hellyer',NULL,NULL,NULL,'','',NULL,NULL,'andrew@bunyiptoys.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(4,'Zak','Sequoia',NULL,NULL,NULL,'','0456 924 695',NULL,NULL,'zak@woodenpier.com',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(5,'Len','Slater',NULL,NULL,NULL,'64921891 ','0437 385 018',NULL,NULL,'lenandwendy@internode.on.net',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(6,'Tom','Dawson',NULL,NULL,NULL,'','0412 880 471',NULL,NULL,'tom.dawson@steeline.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(7,'Jo','Ruiz-Avila',NULL,NULL,NULL,'','',NULL,NULL,'sydney@akt-kix.com',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(8,'David','Girardeau',NULL,NULL,NULL,'','0407503182',NULL,NULL,'ffdrafting@hotmail.com',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(9,'','',NULL,NULL,NULL,'','',NULL,NULL,'christiea@scbuslines.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(10,'Rachel','Jones',NULL,NULL,NULL,'','0429 910 317',NULL,NULL,'Rachel@scwl.org.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(11,'Robert','lockerbie',NULL,NULL,NULL,'6492 6500','0423 812 962',NULL,NULL,'robert.lockerbie@gmail.com',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(12,'Shereene','Simpson',NULL,NULL,NULL,'6495 3555','',NULL,NULL,'shereene@merimbularealty.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(13,'Leanne','Atkinson',NULL,NULL,NULL,'','0414 417 315',NULL,NULL,'leanneatkinson1@gmail.com',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(14,'Robyn','Lunt',NULL,NULL,NULL,'64553361','',NULL,NULL,'',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(15,'Trent','Pool',NULL,NULL,NULL,'','',NULL,NULL,'trent@merimbularealty.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(16,'Bev','Parker',NULL,NULL,NULL,'','',NULL,NULL,'bev@merimbularealty.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(17,'Scott','Glendinning',NULL,NULL,NULL,'08 9381 3311','0407 755 190',NULL,NULL,'sg@mindfield.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(18,'Jon','Kelly',NULL,NULL,NULL,'6495 3026','0428 954 662',NULL,NULL,'jon@merimbularealty.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(19,'Paul','Judd',NULL,NULL,NULL,'6495 6452','',NULL,NULL,'paulj@scbuslines.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(20,'Jamie','Klemm',NULL,NULL,NULL,'6495 6452','',NULL,NULL,'jamiek@scbuslines.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(21,'Bob','McAlister',NULL,NULL,NULL,'','',NULL,NULL,'BMcAlister@begavalley.nsw.gov.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(22,'Doug','Robertson',NULL,NULL,NULL,'','0488242488',NULL,NULL,'douglasjames.au@gmail.com',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(23,'Meredith','Lyons',NULL,NULL,NULL,'','',NULL,NULL,'meredith@designcentral.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(24,'Belinda','Nunn',NULL,NULL,NULL,'','',NULL,NULL,'belinda@tannersalt.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(25,'Karen','Machan',NULL,NULL,NULL,'','',NULL,NULL,'karen.machan@tulgeen.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(26,'Jen','Taylor',NULL,NULL,NULL,'','',NULL,NULL,'jen.taylor@tulgeen.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(27,'Heather','Buckland',NULL,NULL,NULL,'','',NULL,NULL,'heather.buckland@tulgeen.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(28,'Lesley','Minto',NULL,NULL,NULL,'','',NULL,NULL,'lesley.minto@tulgeen.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(29,'Taryn','Beesley',NULL,NULL,NULL,'02 6492 3222','',NULL,NULL,'taryn.beesley@workability.net.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(30,'Elaine','Philips',NULL,NULL,NULL,'','0419 408 902',NULL,NULL,'',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(31,'Merrilie','Insch',NULL,NULL,NULL,'02 64952299','0448019537',NULL,NULL,'fun@magicmountain.net.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(32,'Administrator','Administrator',NULL,NULL,NULL,'','',NULL,NULL,'administrator@tulgeen.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(33,'Joanne','McNamara',NULL,NULL,NULL,'','',NULL,NULL,'joanne.mcnamara@tulgeen.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(34,'Kevin','Gerathy',NULL,NULL,NULL,'02 64951216','0411540090',NULL,NULL,'office@beachcabins.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(35,'Dave','Sparks',NULL,NULL,NULL,'','0400027545',NULL,NULL,'pirate_studios@yahoo.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(36,'Carey','Dessaix',NULL,NULL,NULL,'','0405 305 198',NULL,NULL,'carey@dessaix.com',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(37,'Gae','Rheinberger',NULL,NULL,NULL,'','0409 463 709',NULL,NULL,'Gae.Rheinberger@tulgeen.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(38,'Kass','Fenton',NULL,NULL,NULL,'','',NULL,NULL,'kass.fenton@tulgeen.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(39,'Gary','Johnston',NULL,NULL,NULL,'','0411 598801',NULL,NULL,'gary@johmar.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(40,'Rachel','Choy',NULL,NULL,NULL,'','',NULL,NULL,'rachel.choy@tulgeen.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(41,'Dianne','Rees',NULL,NULL,NULL,'','',NULL,NULL,'dianne.rees@tulgeen.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(42,'Kristi','Sproates',NULL,NULL,NULL,'','',NULL,NULL,'kristi.sproates@tulgeen.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(43,'Sue','Hartemink',NULL,NULL,NULL,'','0421414476',NULL,NULL,'sue.hartemink@tulgeen.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(44,'Edward','Jeffries',NULL,NULL,NULL,'03 8660 1972','0448 504 440',NULL,NULL,'edward.jeffries@stbarbara.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(45,'Julian','Kemp',NULL,NULL,NULL,'03 8660 1920','0407 552 588',NULL,NULL,'julian.kemp@stbarbara.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(46,'Mitch','van Reesch',NULL,NULL,NULL,'','',NULL,NULL,'mitch.van.reesch@tulgeen.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(47,'Accounts','',NULL,NULL,NULL,'','',NULL,NULL,'acc_pay@debortoli.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(48,'Paul','Spiteri',NULL,NULL,NULL,'64990807','',NULL,NULL,'paul.spiteri@tulgeen.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(49,'Sarah','Spurling',NULL,NULL,NULL,'','',NULL,NULL,'sarah.spurling@tulgeen.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(50,'Nick','Machan',NULL,NULL,NULL,'','',NULL,NULL,'nick.machan@tulgeen.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(51,'Kylie','Furnell',NULL,NULL,NULL,'02 6492 3944','0427 771927',NULL,NULL,'Kylief@auswideprojects.org.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(52,'Carste','Eckelmann',NULL,NULL,NULL,'','0458795544',NULL,NULL,'carsten.eckelmann@tulgeen.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(53,'Natalie','Godward',NULL,NULL,NULL,'','0434058871',NULL,NULL,'natalie@merimbulajewellers.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(54,'Paul','McCooey',NULL,NULL,NULL,'','0410 468 890',NULL,NULL,'admin@splashinternet.net.org',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(55,'Tony','Dean',NULL,NULL,NULL,'','',NULL,NULL,'info@medalartmint.com',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(56,'Andrew','Breheny',NULL,NULL,NULL,'','0428720867',NULL,NULL,'andrewbreheny@hotmail.com',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(57,'Jamie','Shaw',NULL,NULL,NULL,'','0427227083',NULL,NULL,'jamie@jdshaw.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(58,'Rachel','Choy',NULL,NULL,NULL,'','',NULL,NULL,'rachel@abphotography.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(59,'Andrea','Cuthbert',NULL,NULL,NULL,'','0402242163',NULL,NULL,'andrea.cuthbert@tulgeen.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(60,'John','Hobbes',NULL,NULL,NULL,'02 9542 2000','',NULL,NULL,'',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(61,'Josh','Dorrough',NULL,NULL,NULL,'6494 2744','',NULL,NULL,'josh.dorrough@naturalregen.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(62,'Brenda','',NULL,NULL,NULL,'(02) 6495 7077','',NULL,NULL,'scfscf@bigpond.com',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(63,'Damian','Foley',NULL,NULL,NULL,'','',NULL,NULL,'dfoley@clubsapphire.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(64,'Deb','Pippen',NULL,NULL,NULL,'(02) 6247 1026','',NULL,NULL,'DebP@tenantsact.org.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(65,'Adelaide','Rief',NULL,NULL,NULL,'(02) 6247 1026','',NULL,NULL,'AdelaideR@tenantsact.org.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(66,'David','Edwards',NULL,NULL,NULL,'02 6162 0900','',NULL,NULL,'oscar@mont.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(67,'Nick','Graham-Higgs',NULL,NULL,NULL,'','0427 260 819',NULL,NULL,'nick.gh@nghenvironmental.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(68,'Robert','Green',NULL,NULL,NULL,'6282 2667','0402 647 040',NULL,NULL,'robert@wheatfields.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(69,'Rose','Hulst',NULL,NULL,NULL,'','0438 924 151',NULL,NULL,'rose.hulst@tulgeen.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(70,'Peter','Gorton',NULL,NULL,NULL,'','',NULL,NULL,'peter.gorton@tulgeen.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(71,'Bill','Robertson',NULL,NULL,NULL,'02 69 660 100','',NULL,NULL,'bill_robertson@debortoli.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(72,'Simone','Eyles',NULL,NULL,NULL,'','',NULL,NULL,'simone@365cups.com',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(73,'Anthony','Osborne',NULL,NULL,NULL,'','0428 243 539',NULL,NULL,'aosborne@sapphirecoast.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(74,'Anthony','Marshall',NULL,NULL,NULL,'6455 7552','',NULL,NULL,'anthony@birdsnest.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(75,'Paul','Butler',NULL,NULL,NULL,'02 8113 5600','0402 415 788',NULL,NULL,'pbutler@valmorgan.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(76,'Shane','Ardern',NULL,NULL,NULL,'6499 0805','0435 055 405',NULL,NULL,'shane.ardern@tulgeen.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(77,'Yifan','Yang',NULL,NULL,NULL,'','0425 209 736',NULL,NULL,'yang.yifan0@gmail.com',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(78,'Stephen','Garrett',NULL,NULL,NULL,'','0410047122',NULL,NULL,'stephen@pyramidpower.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(79,'Paul','Boillat',NULL,NULL,NULL,'','0458855768',NULL,NULL,'paulboillat@internode.on.net',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(80,'Helene','Garrett',NULL,NULL,NULL,'','0428 590 084',NULL,NULL,'helene@pyramidpower.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(81,'Don','Peterson',NULL,NULL,NULL,'','',NULL,NULL,'donp@fnfc.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(82,'Jo','Thorpe',NULL,NULL,NULL,'','',NULL,NULL,'jo.thorpe@fnfc.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(83,'Andy','Willis',NULL,NULL,NULL,'+61 2 6499 0651','+61 408 923 599',NULL,NULL,'andy@conferencecomplete.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(84,'Neil','Dawson',NULL,NULL,NULL,'(02) 6495 6968','0411 440 331',NULL,NULL,'neil.dawson@steeline.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(85,'Brent','Occleshaw',NULL,NULL,NULL,'6494 2133','0419 358 834',NULL,NULL,'brent@gooseboy.tv',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(86,'Natalie','Godward',NULL,NULL,NULL,'','0434 058 871',NULL,NULL,'natalie@ourmerimbula.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(87,'Alan','Mogridge',NULL,NULL,NULL,'02 6495 7320','',NULL,NULL,'alan@excellprint.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(88,'Stephen','Cotteril',NULL,NULL,NULL,'6458 4481','',NULL,NULL,'info@mountainaccountin.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(89,'Sak','Ryopponen',NULL,NULL,NULL,'','0409353894',NULL,NULL,'sak1@iprimus.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(90,'Greg','Coram',NULL,NULL,NULL,'','0448000477',NULL,NULL,'greg.c@nghenvironmental.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(91,'Kerry','Nicholls',NULL,NULL,NULL,'0264941561','0429959187',NULL,NULL,'austinfinance@bigpond.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(92,'Debbie','Isles',NULL,NULL,NULL,'','',NULL,NULL,'merimbulafreshfood@bigpond.com',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(93,'Mick','Hoorweg',NULL,NULL,NULL,'','',NULL,NULL,'mick@switchthree.com',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(94,'Mark','Keltie',NULL,NULL,NULL,'','',NULL,NULL,'',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(95,'Karl','Auer',NULL,NULL,NULL,'','0428 957 160',NULL,NULL,'kauer@nullarbor.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(96,'Robert','Tacheci',NULL,NULL,NULL,'0407 934160','0407 934160',NULL,NULL,'robert@marshallandtacheci.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(97,'Dave','Wilson',NULL,NULL,NULL,'(02) 6458 4191','0408587211',NULL,NULL,'djcoolfreight@bigpond.com',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(98,'Iain','McKimm',NULL,NULL,NULL,'','',NULL,NULL,'Iain.McKimm@begacheese.com.au',NULL,'2014-04-23 06:46:58','2014-04-23 16:46:58',0,NULL,1),(99,'Geoffrey','Grigg',NULL,NULL,NULL,'64925000','0499 302 688',NULL,NULL,'',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(100,'Jackie','Stallard',NULL,NULL,NULL,'44768001','0447 698 874',NULL,NULL,'jackie@austcom.org.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(101,'Steve and Jenni','Jory',NULL,NULL,NULL,'6495 3577','0428 425 759',NULL,NULL,'jenni@enhanceu.com.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(102,'Gabriel','Manchuret',NULL,NULL,NULL,'8003 5188','0419585863',NULL,NULL,'nitrogendreams@gmail.com',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(103,'Lee','Bilby',NULL,NULL,NULL,'1800 245 297','0478 671 131',NULL,NULL,'lee@bilby.net',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(104,'Sylvia','Morrah',NULL,NULL,NULL,' (02) 6492 3597','0448 536 117',NULL,NULL,'sylvia.morrah@sewacs.org.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(105,'Simone','Ficht',NULL,NULL,NULL,'','0403 336 099',NULL,NULL,'simone.ficht@yahoo.com.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(106,'Tracy','Creighton',NULL,NULL,NULL,'6495 4608','',NULL,NULL,'boardwalkart@internode.on.net',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(107,'Rob','High',NULL,NULL,NULL,'6495 9785','',NULL,NULL,'ROB@mandeni.com.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(108,'Paul','Williams',NULL,NULL,NULL,'02 6495 34444','0429 434 670',NULL,NULL,'paul@scauto.com.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(109,'Tess','Williams',NULL,NULL,NULL,'','',NULL,NULL,'tess@scauto.com.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(110,'Larry','Oakley',NULL,NULL,NULL,'02 6494 3232','0428 649 573',NULL,NULL,'twofoldsecurity@dragnet.com.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(111,'Pat','Neville',NULL,NULL,NULL,'02 6494 3232','0488 970 004',NULL,NULL,'twofoldadmin@upnet.net.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(112,'Carsten','Eckelmann',NULL,NULL,NULL,'','',NULL,NULL,'carsten@tripleacs.com',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(113,'Paul','Bailey',NULL,NULL,NULL,'(02) 6495 7216','',NULL,NULL,'pbaileysprojects@gmail.com',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(114,'Penny','Amberg',NULL,NULL,NULL,'','0448 129 420',NULL,NULL,'penny@fourwinds.com.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(115,'Adam','Thomas',NULL,NULL,NULL,'','',NULL,NULL,'adam@prestigeclassiccars.com.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(116,'Armen','Gregorian',NULL,NULL,NULL,'','0414262614',NULL,NULL,'agregorian@airlan.com.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(117,'Sarah','James',NULL,NULL,NULL,'02 6498 5258','0424 918 566',NULL,NULL,'pipeldoot.en.voiture@gmail.com',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(118,'Terry','Went',NULL,NULL,NULL,'','',NULL,NULL,'terry@fourwinds.com.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(119,'Liam','O\'Duibhir',NULL,NULL,NULL,'0417579079','0417579079',NULL,NULL,'liam@tripleacs.com',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(120,'Bennet','Schwartz',NULL,NULL,NULL,'','',NULL,NULL,'bennets87@gmail.com',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(121,'June','Boulton',NULL,NULL,NULL,'','',NULL,NULL,'',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(122,'Roger','Timms',NULL,NULL,NULL,'','',NULL,NULL,'rtimms@acora.com.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(123,'John','Turville',NULL,NULL,NULL,'','0416125418',NULL,NULL,'jturville1@gmail.com',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(124,'Mandy Amanda','Alexander',NULL,NULL,NULL,'(02) 6495 4255','0430 962 966',NULL,NULL,'smiles@sapphiresmiles.com.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(125,'Jo','Goodlock',NULL,NULL,NULL,'02 6492 3222','',NULL,NULL,'jo.goodlock@workability.net.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(126,'Nigel','Ayling',NULL,NULL,NULL,'','0412 463 386',NULL,NULL,'nigel@solutions4.biz',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(127,'Dave','Elliot',NULL,NULL,NULL,'6499 0803','0458 920 000',NULL,NULL,'Dave.Elliott@tulgeen.com.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(128,'Avon','Rollason',NULL,NULL,NULL,'6499 0802','0407 296 507',NULL,NULL,'avon.rollason@tulgeen.com.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(129,'Jon','Oakes',NULL,NULL,NULL,'','',NULL,NULL,'jon.oakes@artifax.com.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(130,'Jon','Oakes',NULL,NULL,NULL,'','',NULL,NULL,'jon.oakes@get-smart.com.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(131,'Grant','Keogh',NULL,NULL,NULL,'','',NULL,NULL,'',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(132,'Chris','Sheedy',NULL,NULL,NULL,'','0420578746',NULL,NULL,'cbsheedy@gmail.com',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(133,'Cheryl','Nelson',NULL,NULL,NULL,' (02) 6492 3597','0411 172 447',NULL,NULL,'Cheryl.Nelson@sewacs.org.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(134,'Jane','McKinnon',NULL,NULL,NULL,'','',NULL,NULL,'manager@tbfp.com.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(135,'Frank J','Holden',NULL,NULL,NULL,'','',NULL,NULL,'',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(136,'Symony','Douglas',NULL,NULL,NULL,'','0416398952',NULL,NULL,'symonyj@hotmail.com',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(137,'Caroline','Long',NULL,NULL,NULL,'(02) 6492 2223','0428 136 196',NULL,NULL,'Caroline.Long@bwr.org.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(138,'Roger','Bunyan',NULL,NULL,NULL,'02 6492 7202','0419 424 829',NULL,NULL,'roger@redgumweb.com.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(139,'Darryl','Butler',NULL,NULL,NULL,'','',NULL,NULL,'darryl@itchybrain.com.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(140,'Chris','Bilby',NULL,NULL,NULL,'','0431 089 143',NULL,NULL,'chris@bilby.net',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(141,'Libby','Hepburn',NULL,NULL,NULL,'','0458 798 990',NULL,NULL,'libby.alanhepburn@bigpond.com',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(142,'Linden','Daniel',NULL,NULL,NULL,'','0427 186 633',NULL,NULL,'danielvets@hotmail.com',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(143,'Justin','Daniel',NULL,NULL,NULL,'','0427 771 424',NULL,NULL,'',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(144,'Brenda','Daly',NULL,NULL,NULL,'','',NULL,NULL,'dalby@netspace.net.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(145,'Malcolm','Hurley',NULL,NULL,NULL,'','',NULL,NULL,'',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(146,'Belinda','Hurley',NULL,NULL,NULL,'(02)6458 4700','',NULL,NULL,'mchweld@bigpond.net.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(147,'Anthony','Daly',NULL,NULL,NULL,'','0411 090 420',NULL,NULL,'nindaly@bigpond.com',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(148,'John','McDermott',NULL,NULL,NULL,'(02) 6495 6147','',NULL,NULL,'',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(149,'Cath','Turville',NULL,NULL,NULL,'','0409 153 964',NULL,NULL,'cath@gemenviro.com.au',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1),(150,'Janine','McDermott',NULL,NULL,NULL,'','0428949144',NULL,NULL,'jm.auto@bigpond.com',NULL,'2014-04-23 06:46:59','2014-04-23 16:46:59',0,NULL,1);
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_account`
--

DROP TABLE IF EXISTS `crm_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_account` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `acm_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_domain` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `abn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `acn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bank_bsb` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bank_account` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `terms_id` bigint(20) DEFAULT NULL,
  `use_gst` tinyint(1) NOT NULL DEFAULT '1',
  `referrer_account_id` bigint(20) DEFAULT NULL,
  `referral_rank` int(11) DEFAULT NULL,
  `billing_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `billing_suburb` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `billing_state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `billing_country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `main_crm_contact_id` bigint(20) DEFAULT NULL,
  `billing_crm_contact_id` bigint(20) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dt_created` datetime NOT NULL,
  `dt_modified` datetime NOT NULL,
  `creator_id` bigint(20) DEFAULT NULL,
  `modifier_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_account`
--

LOCK TABLES `crm_account` WRITE;
/*!40000 ALTER TABLE `crm_account` DISABLE KEYS */;
INSERT INTO `crm_account` VALUES (1,NULL,'Adam','Lead','<p>Asdf</p>','http://adbuckley.com','','','','Private Company','','',NULL,1,NULL,0,'','','','',NULL,NULL,1,0,'2014-03-21 15:46:31','2014-04-11 14:41:27',1,1),(2,NULL,'Test','Customer','','','','','','Private Company','','',0,1,NULL,0,'','','','',NULL,NULL,1,0,'2014-04-23 15:16:13','2014-04-23 15:16:13',1,1),(3,'965576000002073003','Bunyip Toys','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(4,'965576000002061035','The Change Agency (Zak Sequoia)','Customer','','http://thechangeagency.org/','thechangeagency.org',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(5,'965576000002061023','Bermagui Seaview Beachhouses','Customer','','http://seaviewbeachhouses.com.au/','seaviewbeachhouses.com.au',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(6,'965576000002061003','Pambula Engineering','Customer','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(7,'965576000001989020','Marlo Hotel','Customer','','http://www.marlohotel.com.au/','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(8,'965576000001964254','Community Training Partnerships ','Customer','','http://communitytrainingpartnerships.org.au/','communitytrainingpartnerships.org.au',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(9,'965576000001958003','Department of Health(Cooma)','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(10,'965576000001896407','Mindfield','Lead','sent via Vickie, Roger\'s partner.','www.mindfield.com.au','mindfield.com.au',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(11,'965576000001894159','Merimbula Realty','Customer','<span style=\"color: rgb(255,255,255);font-family: Arial , Helvetica , sans-serif;font-size: 11.0px;background-color: rgb(49,33,107);\">Merimbula Realty Shop 3/11 Merimbula Drive Merimbula NSW</span>','http://www.merimbularealty.com.au/','merimbularealty.com.au',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Merimbula Realty Shop 3/11 Merimbula Drive','Merimbula ','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(12,'965576000001886017','Sapphire Coast Buslines','Customer','<span style=\"font-family: Arial , Helvetica , sans-serif;font-size: 14.0px;background-color: rgb(255,255,255);\">&nbsp;</span>','scbuslines.com.au','scbuslines.com.au',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'39 Redfern Close / PO Box 256','South Pambula','NSW ','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(13,'965576000001813084','Bega Valley Shire Council','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(14,'965576000001779291','Doug Robertson Draft Engineering','Customer','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(15,'965576000001651003','Design Central','Partner','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(16,'965576000001644044','Nullarbor Consulting Pty Ltd','Customer','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'PO Box 94','Pambula','NSW','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(17,'965576000001616046','Tanner Salt','Lead','','http://tannersalt.com.au','tannersalt.com.au',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(18,'965576000001423113','Magic Mountain','Customer','','http://magicmountain.net.au','magicmountain.net.au',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(19,'965576000001406224','Merimbula Visitor Information Centre','Customer','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(20,'965576000001308515','Johnston Marketing','Customer','','www.johmar.com.au','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(21,'965576000001257018','St Barbara Limited','Customer','currently customer for hosting of Carsten. Soon to be moved to TripleAcs.','http://stbarbara.com.au','stbarbara.com.au',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Level 10, 432 St Kilda road','Melbourne','VIC','Australia',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(22,'965576000001098233','Kanbanflow','Vendor','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(23,'965576000001098219','Google','Vendor','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(24,'965576000001098180','Crazy Domains Pty Ltd','Vendor','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(25,'965576000001098150','Panthur Pty Ltd','Vendor','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(26,'965576000001098138','HUNTER/AON Insurances','Vendor','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(27,'965576000001098110','QBE Insurances','Vendor','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(28,'965576000001098102','No Fuss Bookkeeping','Vendor','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(29,'965576000001098092','ANZ Bank','Vendor','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(30,'965576000001098046','Zoho Corporation','Vendor','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(31,'965576000001098040','Paul Lewis Data Cabling','Vendor','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(32,'965576000001098032','Matt Edebohl','Partner','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(33,'965576000001098015','Adam Buckley','Partner','developer','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(34,'965576000001095760','Yifan Yang','Partner','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(35,'965576000001095752','Fred Wood Electrical','Vendor','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(36,'965576000001095716','Jason Richards','Vendor','IT support in Moruya, Batemans Bay','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(37,'965576000001072240','Merimbula Jewellers','Customer','contacted us for moving their website to our hosting.','http://www.merimbulajewellers.com.au','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(38,'965576000001041030','Splash Internet','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(39,'965576000001041022','Medal Art Mint','Lead','Friend of Jamie Shaw Bega','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(40,'965576000001029003','Andrew Breheny','Vendor','Electrical Contractor','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(41,'965576000001026028','Jamie Shaw','Customer','Author','jdshaw.com.au','jdshaw.com.au',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(42,'965576000000990053','Andy Brown Photography','Customer','Rachel Choy\'s Partner','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(43,'965576000000986003','Andrea Cuthbert','Customer','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(44,'965576000000932003','Micronet','Vendor','CRM system provider for Steeline.<br>','http://www.micronet.com.au','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(45,'965576000000907003','Natural Regeneration Australia Pty Ltd','Customer','','http://naturalregen.com.au','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(46,'965576000000890003','Neil Burge (Tuscany Apartments)','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(47,'965576000000875113','Sapphire Coast FUNERALS','Customer','<p class=\"MsoNormal\" style=\"margin: 0px; color: rgb(34, 34, 34); font-family: arial, sans-serif; font-size: 12.571428298950195px; background-color: rgb(255, 255, 255);\"><span style=\"font-size: 13pt; font-family: Vivaldi; color: rgb(23, 54, 93);\">Sapphire Coast</span><b><span style=\"font-size: 16pt; font-family: Vivaldi; color: rgb(23, 54, 93);\">&nbsp;</span></b><span style=\"font-size: 11pt; font-family: Garamond, serif; color: rgb(23, 54, 93);\">FUNERALS</span><span style=\"font-size: 16pt; font-family: Garamond, serif; color: rgb(23, 54, 93);\">&nbsp;</span><span style=\"font-size: 8pt; font-family: Garamond, serif; color: rgb(23, 54, 93);\">PtyLtd</span><span style=\"font-size: 11pt; font-family: \'Times New Roman\', serif; color: rgb(23, 54, 93);\"><u></u><u></u></span></p><p class=\"MsoNormal\" style=\"margin: 0px; color: rgb(34, 34, 34); font-family: arial, sans-serif; font-size: 12.571428298950195px; background-color: rgb(255, 255, 255); line-height: 12pt;\"><span lang=\"EN-US\" style=\"font-size: 9pt; font-family: Garamond, serif; color: rgb(23, 54, 93);\">Munje Street, PAMBULA NSW 2549&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<wbr>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<wbr>&nbsp;&nbsp;&nbsp;&nbsp;<u></u><u></u></span></p><p class=\"MsoNormal\" style=\"margin: 0px; color: rgb(34, 34, 34); font-family: arial, sans-serif; font-size: 12.571428298950195px; background-color: rgb(255, 255, 255);\"><span lang=\"EN-US\" style=\"font-size: 9pt; font-family: Garamond, serif; color: rgb(23, 54, 93);\">Telephone (02) 6495 7077&nbsp; Fax (02) 6495 7184</span><span style=\"font-size: 11pt; font-family: \'Times New Roman\', serif; color: rgb(23, 54, 93);\"><u></u><u></u></span></p><p class=\"MsoNormal\" style=\"margin: 0px; color: rgb(34, 34, 34); font-family: arial, sans-serif; font-size: 12.571428298950195px; background-color: rgb(255, 255, 255);\"><br></p>','www.sapphirecoastfunerals.com.au','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(48,'965576000000868227','Club Sapphire (Merimbula Bowling Club)','Lead','Currently a SOS customer<div><br></div><div>Referred by Iain McKimm</div>','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(49,'965576000000859142','Mont Adventure Equipment','Customer','currently a client of Darryl\'s. First contact through malware problem.<br>','http://mont.com.au','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'14 Pirie Street','Fyshwick','ACT','Australia',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(50,'965576000000848293','Tenants Union ACT','Lead','Darryl\'s client. First project is a javascript rent calculator.<br>','http://www.tenantsact.org.au/','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'PO Box 8','Civic Square','ACT','Australia',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(51,'965576000000837003','Robert Green (Wheatfields)','Lead','Owner of office space throughout Merimbula','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(52,'965576000000799031','365Cups.com','Customer','','365cups.com','','','','','','',0,1,NULL,0,'','','','',71,0,1,0,'2014-04-23 15:32:55','2014-04-23 17:06:20',1,1),(53,'965576000000799019','Sapphire Coast Tourism','Customer','','www.sapphirecoast.com.au','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(54,'965576000000797110','Val Morgan','Customer','Val Morgan are a cinema advertising company that also provide TV entertainment in shopping centers and car washes, etc.<br><br>Carsten currently provides hosting services for them, but will move this into the TripleACS brand in June when the next 6 months hosting comes up.<br>','http://www.valmorgan.com.au','valmorgan.com.au',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(55,'965576000000718360','GottaGetaway','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Main St','Merimbula','New South Wales','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(56,'965576000000718356','Excell Printing','Customer','','www.excellprint.com.au','excellprint.com.au',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','Pambula','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(57,'965576000000718352','Conference Complete','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(58,'965576000000718348','Steeline','Customer','','http://steelinetanks.com.au','steeline.com.au',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'4 Bullara Street','Pambula','NSW','Australia',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(59,'965576000000718344','Gooseboy','Partner','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1),(60,'965576000000718340','Merimbula Chamber of Commerce','Customer','','http://ourmerimbula.com.au','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(61,'965576000000718336','No Fuss Accounting (frmrly Mountain Accountin)','Partner','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(62,'965576000000718332','Go Tech','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(63,'965576000000718328','NGH Environmental','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(64,'965576000000718324','Auswide','Customer','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(65,'965576000000718320','Merimbula Fresh Food','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(66,'965576000000718316','Airport Services Merimbula','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(67,'965576000000718312','Merimbula.com.au (Mark Keltie)','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(68,'965576000000718308','IPV6','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(69,'965576000000718304','Marshall & Tacheci Real Estate','Customer','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'28 Lamont St.','Bermagui','NSW','Australia',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(70,'965576000000718300','DJ Cool Freight','Customer','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(71,'965576000000718296','Bega Cheese','Customer','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(72,'965576000000718292','Austcom/Webhive Bega','Customer','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(73,'965576000000718288','Danius Maragus','Customer','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(74,'965576000000718280','Mandeni','Customer','','mandeni.com.au','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'489 Red Hill Road,','Bournda','NSW','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(75,'965576000000718276','EnhanceU','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(76,'965576000000718272','SEO Ninja (Gabriel Manchuret)','Partner','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(77,'965576000000718268','Bilby CNC','Customer','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(78,'965576000000718264','SEWACS','Customer','','','sewacs.org.au',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(79,'965576000000718256','Pambula Real Estate (Simone Ficht)','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(80,'965576000000718252','Boardwalk Art','Customer','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(81,'965576000000718248','Four Winds Festival','Customer','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Bermagui Community Centre 1 Young Street','Bermagui','NSW','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(82,'965576000000718244','Birds Nest','Customer','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','Cooma','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(83,'965576000000718240','South Coast Auto Centre (Goodyear/Hertz)','Customer','','','scauto.com.au',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'39 Merimbula Drive','Merimbula','NSW','Australia',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(84,'965576000000718236','Twofold Security','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(85,'965576000000718232','Seashells Apartments (Michael Dixon)','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(86,'965576000000718228','iSpy iPhone App','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(87,'965576000000718224','TripleACS Pty Ltd','Partner','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(88,'965576000000718220','Pyramid Power','Customer','Taking over hosting of Flow.','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(89,'965576000000718216','Prestige Classic Cars','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(90,'965576000000718212','Tulgeen','Customer','','http://www.tulgeen.com.au','tulgeen.com.au',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(91,'965576000000718208','Zoho Corporation','Vendor','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(92,'965576000000718204','Saasu Pty Ltd','Vendor','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(93,'965576000000718200','Warcom Pty Ltd (Vendor)','Vendor','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(94,'965576000000718196','OneSaas Pty Ltd','Vendor','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(95,'965576000000718192','Airlan Wireless','Partner','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(96,'965576000000718188','Sarah James','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(97,'965576000000718184','Workability','Customer','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(98,'965576000000718180','Bennet Schwartz','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,0,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(99,'965576000000718176','Acora','Customer','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(100,'965576000000718172','GEM Enviro','Customer','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Suite 1, Unit 1, 239 Carp Str','Bega','NSW','Australia',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(101,'965576000000718168','Sapphire Smiles','Customer','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Unit 3, 5 Palmer La','Merimbula','NSW','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(102,'965576000000718164','Solutions 4 Biz','Customer','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(103,'965576000000718160','Artifax','Partner','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(104,'965576000000718156','Get Smart Consulting','Partner','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'PO Box 420,','Pambula','NSW','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(105,'965576000000718152','Edge FM Radio','Customer','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(106,'965576000000718148','Burwood Clivia','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(107,'965576000000718144','Tathra Beach Family Park','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(108,'965576000000718140','Redgumweb Pty Ltd','Partner','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(109,'965576000000718136','De Bortoli Wines','Customer','','','debortoli.com.au',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(110,'965576000000718132','Mandala Alchemy Pty Ltd','Partner','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(111,'965576000000718128','Boillat Refrigeration','Vendor','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(112,'965576000000718124','Atlas of Life in the Coastal Wilderness (ALCW)','Customer','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(113,'965576000000718120','Daniel Veterinary Pambula','Customer','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'4 Bolara St','Pambula','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(114,'965576000000718116','Wesson Stories Inc Pty Ltd','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'140 Upper Heidelberg Road','Ivanhoe','VIC','Australia',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(115,'965576000000718112','MCH Welding Bombala','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(116,'965576000000718108','John McDermott Motors','Customer','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'14 Sir William McKell Dr','Pambula','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1),(117,'965576000000718104','Merimbula Wharf Aquarium','Lead','','','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'','','','',NULL,NULL,1,0,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1);
/*!40000 ALTER TABLE `crm_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_company_setting`
--

DROP TABLE IF EXISTS `crm_company_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_company_setting` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `account_id` bigint(20) NOT NULL,
  `tfn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `accounting_system` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `creator_id` bigint(20) NOT NULL,
  `modifier_id` bigint(20) NOT NULL,
  `dt_created` datetime NOT NULL,
  `dt_modified` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_company_setting`
--

LOCK TABLES `crm_company_setting` WRITE;
/*!40000 ALTER TABLE `crm_company_setting` DISABLE KEYS */;
INSERT INTO `crm_company_setting` VALUES (1,1,'12345678901','Saasu',1,1,'2014-04-14 14:11:01','2014-04-14 14:11:01',0,1);
/*!40000 ALTER TABLE `crm_company_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_contact`
--

DROP TABLE IF EXISTS `crm_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_contact` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `acm_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_id` bigint(20) NOT NULL,
  `crm_account_id` bigint(20) DEFAULT NULL,
  `position` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `department` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `dt_created` datetime DEFAULT NULL,
  `dt_modified` datetime DEFAULT NULL,
  `creator_id` bigint(20) DEFAULT NULL,
  `modifier_id` bigint(20) DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_contact`
--

LOCK TABLES `crm_contact` WRITE;
/*!40000 ALTER TABLE `crm_contact` DISABLE KEYS */;
INSERT INTO `crm_contact` VALUES (1,NULL,2,1,'CEO','ALL','<p>Cool guy</p>','2014-04-11 14:52:00','2014-04-11 14:52:00',1,1,0),(2,'965576000002073007',3,3,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(3,'965576000002061039',4,4,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(4,'965576000002061027',5,5,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(5,'965576000002061015',6,58,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(6,'965576000002061011',7,6,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(7,'965576000002061007',8,6,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(8,'965576000002058007',9,12,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(9,'965576000001989024',10,7,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(10,'965576000001989016',11,NULL,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(11,'965576000001970007',12,11,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(12,'965576000001964258',13,8,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(13,'965576000001958007',14,12,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(14,'965576000001944007',15,11,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(15,'965576000001943007',16,11,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(16,'965576000001896411',17,10,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(17,'965576000001894163',18,11,'Joint Business Owner','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(18,'965576000001886025',19,12,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(19,'965576000001886021',20,12,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(20,'965576000001813088',21,13,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(21,'965576000001779295',22,14,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(22,'965576000001651007',23,15,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(23,'965576000001616050',24,17,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(24,'965576000001612007',25,90,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(25,'965576000001611007',26,90,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(26,'965576000001604007',27,90,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(27,'965576000001603007',28,90,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(28,'965576000001519092',29,97,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(29,'965576000001434007',30,18,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(30,'965576000001434003',31,18,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(31,'965576000001419007',32,90,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(32,'965576000001415007',33,90,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(33,'965576000001406228',34,19,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(34,'965576000001334272',35,NULL,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(35,'965576000001334044',36,NULL,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(36,'965576000001315086',37,90,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(37,'965576000001309007',38,90,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(38,'965576000001308519',39,20,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(39,'965576000001271042',40,90,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(40,'965576000001270025',41,90,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(41,'965576000001270007',42,90,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(42,'965576000001268162',43,90,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(43,'965576000001257222',44,21,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(44,'965576000001257218',45,21,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(45,'965576000001249007',46,90,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(46,'965576000001245018',47,109,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(47,'965576000001244007',48,90,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(48,'965576000001221007',49,90,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(49,'965576000001220007',50,90,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(50,'965576000001219007',51,64,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(51,'965576000001203996',52,90,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(52,'965576000001072248',53,37,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(53,'965576000001041034',54,38,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(54,'965576000001041026',55,39,'','','Address...back of Spiral Gallery Bega','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(55,'965576000001029007',56,40,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(56,'965576000001026032',57,41,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(57,'965576000000990057',58,42,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(58,'965576000000986007',59,43,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(59,'965576000000932007',60,44,'','','Technical Consultant at Micronet<br>','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(60,'965576000000907007',61,45,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(61,'965576000000875117',62,47,'','','Munje St Pambula','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(62,'965576000000868231',63,48,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(63,'965576000000867168',64,50,'Manager','','Receiver of quotes/invoices<br>','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(64,'965576000000867164',65,50,'Tenancy Advisor/ Project Worker','','main contact for project work.<br>','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(65,'965576000000859146',66,49,'Director','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(66,'965576000000846020',67,63,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(67,'965576000000837007',68,51,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(68,'965576000000821011',69,90,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(69,'965576000000801897',70,90,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(70,'965576000000800011',71,109,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(71,'965576000000799035',72,52,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(72,'965576000000799023',73,53,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(73,'965576000000799003',74,82,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(74,'965576000000797114',75,54,'','','Paul Butler is the main contact for all IT projects at Val Morgan.<br>','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(75,'965576000000788018',76,90,'Org Dev Co-ord','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(76,'965576000000751040',77,NULL,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(77,'965576000000751036',78,88,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(78,'965576000000751032',79,111,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(79,'965576000000751028',80,88,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(80,'965576000000719418',81,55,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(81,'965576000000719414',82,55,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(82,'965576000000719410',83,57,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(83,'965576000000719406',84,58,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(84,'965576000000719402',85,59,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(85,'965576000000719398',86,60,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(86,'965576000000719394',87,56,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(87,'965576000000719390',88,61,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(88,'965576000000719386',89,62,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(89,'965576000000719382',90,63,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(90,'965576000000719378',91,NULL,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(91,'965576000000719374',92,65,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(92,'965576000000719370',93,73,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(93,'965576000000719366',94,67,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(94,'965576000000719362',95,16,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(95,'965576000000719358',96,69,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(96,'965576000000719354',97,70,'','','','2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,0),(97,'965576000000719350',98,71,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(98,'965576000000719346',99,72,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(99,'965576000000719342',100,72,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(100,'965576000000719338',101,75,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(101,'965576000000719334',102,76,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(102,'965576000000719330',103,77,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(103,'965576000000719326',104,78,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(104,'965576000000719322',105,NULL,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(105,'965576000000719318',106,80,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(106,'965576000000719314',107,74,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(107,'965576000000719306',108,83,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(108,'965576000000719302',109,83,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(109,'965576000000719298',110,84,'General Manager','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(110,'965576000000719294',111,84,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(111,'965576000000719290',112,87,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(112,'965576000000719282',113,86,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(113,'965576000000719278',114,81,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(114,'965576000000719274',115,89,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(115,'965576000000719270',116,95,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(116,'965576000000719266',117,96,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(117,'965576000000719262',118,81,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(118,'965576000000719258',119,87,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(119,'965576000000719254',120,98,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(120,'965576000000719250',121,99,'Administrator','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(121,'965576000000719246',122,99,'General Manager','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(122,'965576000000719242',123,100,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(123,'965576000000719238',124,101,'','','Other email -&nbsp;amandaalexander44@hotmail.com<div><br></div><div>Old email -&nbsp;smiles@merimbula-ortho.com.au</div>','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(124,'965576000000719234',125,97,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(125,'965576000000719230',126,102,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(126,'965576000000719226',127,90,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(127,'965576000000719222',128,90,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(128,'965576000000719218',129,103,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(129,'965576000000719214',130,104,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(130,'965576000000719210',131,101,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(131,'965576000000719206',132,105,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(132,'965576000000719202',133,78,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(133,'965576000000719198',134,107,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(134,'965576000000719194',135,107,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(135,'965576000000719190',136,74,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(136,'965576000000719186',137,78,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(137,'965576000000719182',138,108,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(138,'965576000000719178',139,110,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(139,'965576000000719170',140,77,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(140,'965576000000719166',141,112,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(141,'965576000000719162',142,113,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(142,'965576000000719158',143,113,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(143,'965576000000719154',144,114,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(144,'965576000000719150',145,115,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(145,'965576000000719146',146,115,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(146,'965576000000719142',147,117,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(147,'965576000000719138',148,116,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(148,'965576000000719134',149,100,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0),(149,'965576000000719130',150,116,'','','','2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,0);
/*!40000 ALTER TABLE `crm_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_expense`
--

DROP TABLE IF EXISTS `crm_expense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_expense` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `acm_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `expense_user_id` bigint(20) NOT NULL,
  `d_expense_date` date NOT NULL,
  `expense_amount` decimal(10,2) NOT NULL,
  `has_gst` tinyint(1) NOT NULL,
  `gst_amount` decimal(10,5) NOT NULL,
  `expense_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payable_to_account_id` bigint(20) DEFAULT NULL,
  `payable_to_other` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `d_payment_due` date DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `category` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_source` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `billable_to_account_id` bigint(20) DEFAULT NULL,
  `billable_invoice_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `creator_id` bigint(20) NOT NULL,
  `modifier_id` bigint(20) NOT NULL,
  `dt_created` datetime NOT NULL,
  `dt_modified` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `task_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_expense`
--

LOCK TABLES `crm_expense` WRITE;
/*!40000 ALTER TABLE `crm_expense` DISABLE KEYS */;
INSERT INTO `crm_expense` VALUES (1,NULL,1,'2014-04-14',100.00,1,9.09091,'Other Expense',1,'',NULL,'<p>Payment for Kickstarter Project</p>','','Credit Card','Personal Account',1,'',1,1,'2014-04-14 14:45:14','2014-04-14 14:45:14',0,54);
/*!40000 ALTER TABLE `crm_expense` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_form`
--

DROP TABLE IF EXISTS `crm_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_form` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `acm_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `account_id` bigint(20) NOT NULL,
  `crm_contact_id` bigint(20) DEFAULT NULL,
  `terms_id` bigint(20) DEFAULT NULL,
  `template_id` bigint(20) DEFAULT NULL,
  `dt_sent` datetime DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `quote_or_invoice_id` bigint(20) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_subject` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_message` text COLLATE utf8_unicode_ci,
  `email_to` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_cc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_bcc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_from` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `creator_id` bigint(20) DEFAULT NULL,
  `modifier_id` bigint(20) DEFAULT NULL,
  `dt_created` datetime DEFAULT NULL,
  `dt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_form`
--

LOCK TABLES `crm_form` WRITE;
/*!40000 ALTER TABLE `crm_form` DISABLE KEYS */;
INSERT INTO `crm_form` VALUES (1,NULL,1,1,2,NULL,NULL,'Quote',NULL,'Test','213452',NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,'2014-04-14 14:12:30','2014-04-14 14:12:30'),(2,NULL,1,1,2,NULL,NULL,'Quote',NULL,'Test','213453',NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,'2014-04-14 14:13:45','2014-04-14 14:13:46'),(3,NULL,1,1,2,NULL,NULL,'Quote',NULL,'Test','0.000135',NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,'2014-04-14 14:20:30','2014-04-14 14:20:30'),(4,NULL,1,1,2,NULL,NULL,'Quote',NULL,'Test','0.000786',NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,'2014-04-14 14:20:42','2014-04-14 14:20:42'),(5,NULL,1,1,2,NULL,NULL,'Quote',NULL,'Test','0.000963',NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,'2014-04-14 14:21:58','2014-04-14 14:21:58'),(6,NULL,1,1,2,NULL,NULL,'Quote',2,'Test','213457',NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,'2014-04-14 14:22:17','2014-04-14 14:22:17'),(7,NULL,1,1,2,NULL,NULL,'Invoice',1,'Test','213458',NULL,NULL,NULL,NULL,NULL,NULL,1,1,1,'2014-04-14 14:22:23','2014-04-14 14:22:37'),(8,NULL,1,1,2,NULL,NULL,'Invoice',2,'Test','213459',NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,'2014-04-14 14:22:53','2014-04-14 14:22:54');
/*!40000 ALTER TABLE `crm_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_form_line`
--

DROP TABLE IF EXISTS `crm_form_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_form_line` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `acm_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `form_id` bigint(20) NOT NULL,
  `section_id` bigint(20) DEFAULT NULL,
  `line_number` int(11) DEFAULT NULL,
  `item_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `item_description` text COLLATE utf8_unicode_ci,
  `item_amount` decimal(10,2) DEFAULT NULL,
  `item_price` decimal(10,2) DEFAULT NULL,
  `line_total` decimal(10,2) DEFAULT NULL,
  `line_total_gst` decimal(10,2) DEFAULT NULL,
  `is_gst_included` tinyint(1) DEFAULT '1',
  `gst_percent` int(11) DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rate_level` tinyint(1) DEFAULT '1',
  `creator_id` bigint(20) DEFAULT NULL,
  `modifier_id` bigint(20) DEFAULT NULL,
  `dt_created` datetime DEFAULT NULL,
  `dt_modified` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_form_line`
--

LOCK TABLES `crm_form_line` WRITE;
/*!40000 ALTER TABLE `crm_form_line` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_form_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_form_section`
--

DROP TABLE IF EXISTS `crm_form_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_form_section` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `acm_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `form_id` bigint(20) NOT NULL,
  `section_number` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `hourly_rate` decimal(10,2) DEFAULT NULL,
  `is_rate_inherited` tinyint(1) DEFAULT '1',
  `creator_id` bigint(20) DEFAULT NULL,
  `modifier_id` bigint(20) DEFAULT NULL,
  `dt_created` datetime DEFAULT NULL,
  `dt_modified` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_form_section`
--

LOCK TABLES `crm_form_section` WRITE;
/*!40000 ALTER TABLE `crm_form_section` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_form_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_invoice`
--

DROP TABLE IF EXISTS `crm_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_invoice` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `form_id` bigint(20) NOT NULL,
  `crm_quote_id` bigint(20) DEFAULT NULL,
  `crm_project_id` bigint(20) DEFAULT NULL,
  `task_id` bigint(20) DEFAULT NULL,
  `dt_created` datetime DEFAULT NULL,
  `dt_modified` datetime DEFAULT NULL,
  `creator_id` bigint(20) DEFAULT NULL,
  `modifier_id` bigint(20) DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_invoice`
--

LOCK TABLES `crm_invoice` WRITE;
/*!40000 ALTER TABLE `crm_invoice` DISABLE KEYS */;
INSERT INTO `crm_invoice` VALUES (1,7,2,NULL,52,'2014-04-14 14:22:23','2014-04-14 14:22:37',1,1,1),(2,8,1,NULL,53,'2014-04-14 14:22:54','2014-04-14 14:22:54',1,1,0);
/*!40000 ALTER TABLE `crm_invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_opportunity`
--

DROP TABLE IF EXISTS `crm_opportunity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_opportunity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `acm_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `crm_account_id` bigint(20) DEFAULT NULL,
  `crm_contact_id` bigint(20) DEFAULT NULL,
  `task_id` bigint(20) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `probability` int(3) DEFAULT NULL,
  `value` decimal(20,2) DEFAULT NULL,
  `notes` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `d_due_closing` datetime DEFAULT NULL,
  `d_closed` datetime DEFAULT NULL,
  `dt_created` datetime DEFAULT NULL,
  `dt_modified` datetime DEFAULT NULL,
  `creator_id` bigint(20) DEFAULT NULL,
  `modifier_id` bigint(20) DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_opportunity`
--

LOCK TABLES `crm_opportunity` WRITE;
/*!40000 ALTER TABLE `crm_opportunity` DISABLE KEYS */;
INSERT INTO `crm_opportunity` VALUES (1,NULL,1,1,36,'asdf',100,10.00,'<ul><li>asdf</li></ul>','2014-04-25 00:00:00',NULL,NULL,'2014-04-11 16:54:43',NULL,1,0),(2,NULL,1,1,37,'asdf',100,10.00,'<ul><li>asdf</li></ul>','2014-04-25 00:00:00',NULL,NULL,'2014-04-11 16:54:43',NULL,1,0),(3,NULL,1,1,38,'asdf',100,10.00,'<ul><li>asdf</li></ul>','2014-04-25 00:00:00',NULL,NULL,'2014-04-11 16:54:43',NULL,1,0),(4,NULL,1,1,39,'asdf',100,10.00,'<ul><li>asdf</li></ul>','2014-04-25 00:00:00',NULL,NULL,'2014-04-11 16:54:43',NULL,1,0),(5,NULL,1,1,40,'asdf',100,10.00,'<ul><li>asdf</li></ul>','2014-04-25 00:00:00',NULL,NULL,'2014-04-11 16:54:43',NULL,1,0),(6,NULL,1,1,41,'asdf',100,10.00,'<ul><li>asdf</li></ul>','2014-04-25 00:00:00',NULL,NULL,'2014-04-11 16:54:43',NULL,1,0),(7,NULL,1,1,42,'asdf',100,10.00,'<ul><li>asdf</li></ul>','2014-04-25 00:00:00',NULL,NULL,'2014-04-11 16:54:43',NULL,1,0),(8,NULL,1,1,43,'asdf',100,10.00,'<ul><li>asdf</li></ul>','2014-04-25 00:00:00',NULL,NULL,'2014-04-11 16:54:43',NULL,1,0),(9,NULL,1,1,44,'asdf',100,10.00,'<ul><li>asdf</li></ul>','2014-04-25 00:00:00',NULL,NULL,'2014-04-11 16:54:43',NULL,1,0),(10,NULL,1,1,45,'asdf',100,10.00,'<ul><li>asdf</li></ul>','2014-04-25 00:00:00',NULL,NULL,'2014-04-11 16:54:43',NULL,1,0),(11,NULL,1,1,1,'asdf',100,10.00,'<ul><li>asdf</li></ul>','2014-04-25 00:00:00',NULL,NULL,'2014-04-11 16:39:40',NULL,1,0),(12,NULL,1,1,2,'asdf',100,10.00,'<ul><li>asdf</li></ul>','2014-04-25 00:00:00',NULL,NULL,'2014-04-11 16:39:47',NULL,1,0);
/*!40000 ALTER TABLE `crm_opportunity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_project`
--

DROP TABLE IF EXISTS `crm_project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_project` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `crm_account_id` bigint(20) NOT NULL,
  `crm_quote_id` bigint(20) NOT NULL,
  `crm_term_id` bigint(20) DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `d_scheduled_start` date NOT NULL,
  `d_scheduled_end` date NOT NULL,
  `dt_created` datetime NOT NULL,
  `dt_modified` datetime NOT NULL,
  `creator_id` bigint(20) NOT NULL,
  `modifier_id` bigint(20) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_project`
--

LOCK TABLES `crm_project` WRITE;
/*!40000 ALTER TABLE `crm_project` DISABLE KEYS */;
INSERT INTO `crm_project` VALUES (1,1,1,2,'New','2014-04-07','2014-04-30','2014-04-14 14:24:34','2014-04-14 14:24:34',1,1,0,'Test');
/*!40000 ALTER TABLE `crm_project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_project_member`
--

DROP TABLE IF EXISTS `crm_project_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_project_member` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `role` varchar(255) DEFAULT NULL,
  `crm_project_id` bigint(20) NOT NULL,
  `rate_level` int(11) NOT NULL,
  `creator_id` bigint(20) DEFAULT NULL,
  `modifier_id` bigint(20) DEFAULT NULL,
  `dt_created` datetime DEFAULT NULL,
  `dt_modified` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_project_member`
--

LOCK TABLES `crm_project_member` WRITE;
/*!40000 ALTER TABLE `crm_project_member` DISABLE KEYS */;
INSERT INTO `crm_project_member` VALUES (1,1,'OWNER',1,3,1,1,'2014-04-14 14:24:51','2014-04-14 14:24:51',0);
/*!40000 ALTER TABLE `crm_project_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_project_taskgroup`
--

DROP TABLE IF EXISTS `crm_project_taskgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_project_taskgroup` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `crm_project_id` bigint(20) NOT NULL,
  `taskgroup_id` bigint(20) NOT NULL,
  `creator_id` bigint(20) DEFAULT NULL,
  `modifier_id` bigint(20) DEFAULT NULL,
  `dt_created` datetime DEFAULT NULL,
  `dt_modified` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_project_taskgroup`
--

LOCK TABLES `crm_project_taskgroup` WRITE;
/*!40000 ALTER TABLE `crm_project_taskgroup` DISABLE KEYS */;
INSERT INTO `crm_project_taskgroup` VALUES (1,1,5,1,1,'2014-04-14 14:30:12','2014-04-14 14:30:12',0);
/*!40000 ALTER TABLE `crm_project_taskgroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_quote`
--

DROP TABLE IF EXISTS `crm_quote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_quote` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `acm_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `form_id` bigint(20) DEFAULT NULL,
  `task_id` bigint(20) DEFAULT NULL,
  `crm_opportunity_id` bigint(20) DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rejection_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `d_answered` datetime DEFAULT NULL,
  `d_last_followup` datetime DEFAULT NULL,
  `total_hours` decimal(20,2) DEFAULT NULL,
  `total` decimal(20,2) DEFAULT NULL,
  `total_gst` decimal(20,2) DEFAULT NULL,
  `dt_created` datetime DEFAULT NULL,
  `dt_modified` datetime DEFAULT NULL,
  `creator_id` bigint(20) DEFAULT NULL,
  `modifier_id` bigint(20) DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_quote`
--

LOCK TABLES `crm_quote` WRITE;
/*!40000 ALTER TABLE `crm_quote` DISABLE KEYS */;
INSERT INTO `crm_quote` VALUES (1,NULL,5,50,2,NULL,'','2014-04-28 00:00:00',NULL,NULL,NULL,NULL,'2014-04-14 14:21:58','2014-04-14 14:21:58',1,1,0),(2,NULL,6,51,2,NULL,'','2014-04-28 00:00:00',NULL,NULL,NULL,NULL,'2014-04-14 14:22:17','2014-04-14 14:22:17',1,1,0);
/*!40000 ALTER TABLE `crm_quote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_task_time_invoiced`
--

DROP TABLE IF EXISTS `crm_task_time_invoiced`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_task_time_invoiced` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `crm_form_line_id` bigint(20) NOT NULL,
  `task_time_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_task_time_invoiced`
--

LOCK TABLES `crm_task_time_invoiced` WRITE;
/*!40000 ALTER TABLE `crm_task_time_invoiced` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_task_time_invoiced` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_term`
--

DROP TABLE IF EXISTS `crm_term`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_term` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `rate_level1` decimal(10,2) DEFAULT NULL,
  `rate_level2` decimal(10,2) DEFAULT NULL,
  `rate_level3` decimal(10,2) DEFAULT NULL,
  `travel_loading` int(11) DEFAULT NULL,
  `night_loading` int(11) DEFAULT NULL,
  `weekend_loading` int(11) DEFAULT NULL,
  `holiday_loading` int(11) DEFAULT NULL,
  `invoice_due_days` int(11) DEFAULT NULL,
  `invoice_reminder_days` int(11) DEFAULT NULL,
  `quote_valid_days` int(11) DEFAULT NULL,
  `quote_follow_up_days` int(11) DEFAULT NULL,
  `d_valid_from` date DEFAULT NULL,
  `d_valid_to` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dt_created` datetime DEFAULT NULL,
  `dt_modified` datetime DEFAULT NULL,
  `creator_id` bigint(20) DEFAULT NULL,
  `modifier_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_term`
--

LOCK TABLES `crm_term` WRITE;
/*!40000 ALTER TABLE `crm_term` DISABLE KEYS */;
INSERT INTO `crm_term` VALUES (1,'Test',10.00,20.00,40.00,NULL,NULL,NULL,NULL,21,14,21,14,'2014-02-27','2015-05-13',1,1,'2014-04-14 14:06:47','2014-04-14 14:10:30',1,1),(2,'Test',10.00,20.00,40.00,NULL,NULL,NULL,NULL,21,14,21,14,'2014-02-27','2015-05-13',1,0,'2014-04-14 14:10:26','2014-04-14 14:10:26',1,1);
/*!40000 ALTER TABLE `crm_term` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms_application`
--

DROP TABLE IF EXISTS `forms_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms_application` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dt_created` datetime NOT NULL,
  `dt_modified` datetime NOT NULL,
  `creator_id` int(11) NOT NULL,
  `modifier_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms_application`
--

LOCK TABLES `forms_application` WRITE;
/*!40000 ALTER TABLE `forms_application` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms_form`
--

DROP TABLE IF EXISTS `forms_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms_form` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `application_id` int(11) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dt_created` datetime NOT NULL,
  `dt_modified` datetime NOT NULL,
  `creator_id` int(11) NOT NULL,
  `modifier_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms_form`
--

LOCK TABLES `forms_form` WRITE;
/*!40000 ALTER TABLE `forms_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms_form_field`
--

DROP TABLE IF EXISTS `forms_form_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms_form_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `position` int(11) NOT NULL DEFAULT '0',
  `field_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `data_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `date_format` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `time_format` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `select_values` text COLLATE utf8_unicode_ci,
  `select_form_id` int(11) DEFAULT NULL,
  `select_form_field_ids` int(11) DEFAULT NULL,
  `file_types` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_max_size` int(11) DEFAULT NULL,
  `default_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dt_created` datetime NOT NULL,
  `dt_modified` datetime NOT NULL,
  `creator_id` int(11) NOT NULL,
  `modifier_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms_form_field`
--

LOCK TABLES `forms_form_field` WRITE;
/*!40000 ALTER TABLE `forms_form_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms_form_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_user`
--

DROP TABLE IF EXISTS `group_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `dt_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_user`
--

LOCK TABLES `group_user` WRITE;
/*!40000 ALTER TABLE `group_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inbox`
--

DROP TABLE IF EXISTS `inbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inbox` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `sender_id` bigint(20) DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `message_id` bigint(20) DEFAULT NULL,
  `dt_created` datetime NOT NULL,
  `dt_read` datetime DEFAULT NULL,
  `is_new` tinyint(1) NOT NULL DEFAULT '1',
  `dt_archived` datetime DEFAULT NULL,
  `is_archived` tinyint(1) NOT NULL DEFAULT '0',
  `parent_message_id` int(11) DEFAULT NULL,
  `has_parent` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `del_forever` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inbox`
--

LOCK TABLES `inbox` WRITE;
/*!40000 ALTER TABLE `inbox` DISABLE KEYS */;
/*!40000 ALTER TABLE `inbox` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inbox_message`
--

DROP TABLE IF EXISTS `inbox_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inbox_message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `digest` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inbox_message`
--

LOCK TABLES `inbox_message` WRITE;
/*!40000 ALTER TABLE `inbox_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `inbox_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lookup`
--

DROP TABLE IF EXISTS `lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lookup` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `weight` int(11) DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lookup`
--

LOCK TABLES `lookup` WRITE;
/*!40000 ALTER TABLE `lookup` DISABLE KEYS */;
/*!40000 ALTER TABLE `lookup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_history`
--

DROP TABLE IF EXISTS `object_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `object_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `object_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_history`
--

LOCK TABLES `object_history` WRITE;
/*!40000 ALTER TABLE `object_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_history_entry`
--

DROP TABLE IF EXISTS `object_history_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `object_history_entry` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `history_id` bigint(20) NOT NULL,
  `attr_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attr_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_history_entry`
--

LOCK TABLES `object_history_entry` WRITE;
/*!40000 ALTER TABLE `object_history_entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_history_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_index`
--

DROP TABLE IF EXISTS `object_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `object_index` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `dt_created` datetime DEFAULT NULL,
  `dt_modified` datetime DEFAULT NULL,
  `creator_id` bigint(20) DEFAULT NULL,
  `modifier_id` bigint(20) DEFAULT NULL,
  `class_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `object_id` bigint(20) NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  FULLTEXT KEY `object_index_content` (`content`)
) ENGINE=MyISAM AUTO_INCREMENT=340 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_index`
--

LOCK TABLES `object_index` WRITE;
/*!40000 ALTER TABLE `object_index` DISABLE KEYS */;
INSERT INTO `object_index` VALUES (1,'2014-03-21 15:46:31','2014-04-11 14:41:27',1,1,'CrmAccount',1,'adam lead asdf http://adbuckley.com private company'),(2,'2014-04-11 14:52:00','2014-04-11 14:52:00',1,1,'CrmContact',1,'ceo cool guy adam buckley 0422185393 adam.buckley90@gmail.com'),(3,'2014-04-11 16:33:02','2014-04-11 16:54:43',1,1,'CrmOpportunity',5,'asdf 100 10.00 1398348000'),(4,'2014-04-11 16:34:14','2014-04-11 16:54:43',1,1,'CrmOpportunity',6,'asdf 100 10.00 1398348000'),(5,'2014-04-11 16:35:21','2014-04-11 16:54:43',1,1,'CrmOpportunity',7,'asdf 100 10.00 1398348000'),(6,'2014-04-11 16:36:43','2014-04-11 16:54:43',1,1,'CrmOpportunity',8,'asdf 100 10.00 1398348000'),(7,'2014-04-11 16:37:53','2014-04-11 16:54:43',1,1,'CrmOpportunity',9,'asdf 100 10.00 1398348000'),(8,'2014-04-11 16:38:12','2014-04-11 16:54:43',1,1,'CrmOpportunity',10,'asdf 100 10.00 1398348000'),(9,'2014-04-11 16:39:40','2014-04-11 16:39:40',1,1,'CrmOpportunity',11,'asdf 100 1398348000'),(10,'2014-04-11 16:39:40',NULL,1,NULL,'Task',1,'asdf adam qualification normal tasktypecrmopportunity 1397198380'),(11,'2014-04-11 16:39:47','2014-04-11 16:39:47',1,1,'CrmOpportunity',12,'asdf 100 1398348000'),(12,'2014-04-11 16:39:47',NULL,1,NULL,'Task',2,'asdf adam qualification normal tasktypecrmopportunity 1397198387'),(13,'2014-04-11 16:39:58',NULL,1,NULL,'Task',3,'asdf adam qualification normal tasktypecrmopportunity 1397198398'),(14,'2014-04-11 16:40:54',NULL,1,NULL,'Task',4,'asdf adam qualification normal tasktypecrmopportunity 1397198454'),(15,'2014-04-11 16:45:41',NULL,1,NULL,'Task',5,'asdf adam qualification normal tasktypecrmopportunity 1397198741'),(16,'2014-04-11 16:45:50',NULL,1,NULL,'Task',6,'asdf adam qualification normal tasktypecrmopportunity 1397198750'),(17,'2014-04-11 16:46:38',NULL,1,NULL,'Task',7,'asdf adam qualification normal tasktypecrmopportunity 1397198798'),(18,'2014-04-11 16:46:44',NULL,1,NULL,'Task',8,'asdf adam qualification normal tasktypecrmopportunity 1397198804'),(19,'2014-04-11 16:47:09',NULL,1,NULL,'Task',9,'asdf adam qualification normal tasktypecrmopportunity 1397198829'),(20,'2014-04-11 16:47:32',NULL,1,NULL,'Task',10,'asdf adam qualification normal tasktypecrmopportunity 1397198852'),(21,'2014-04-11 16:48:14',NULL,1,NULL,'Task',11,'asdf adam qualification normal tasktypecrmopportunity 1397198894'),(22,'2014-04-11 16:48:26',NULL,1,NULL,'Task',12,'asdf adam qualification normal tasktypecrmopportunity 1397198906'),(23,'2014-04-11 16:48:29',NULL,1,NULL,'Task',13,'asdf adam qualification normal tasktypecrmopportunity 1397198909'),(24,'2014-04-11 16:48:44',NULL,1,NULL,'Task',14,'asdf adam qualification normal tasktypecrmopportunity 1397198924'),(25,'2014-04-11 16:49:04',NULL,1,NULL,'Task',15,'asdf adam qualification normal tasktypecrmopportunity 1397198944'),(26,'2014-04-11 16:49:16',NULL,1,NULL,'Task',16,'asdf adam qualification normal tasktypecrmopportunity 1397198956'),(27,'2014-04-11 16:49:42',NULL,1,NULL,'Task',17,'asdf adam qualification normal tasktypecrmopportunity 1397198982'),(28,'2014-04-11 16:49:43',NULL,1,NULL,'Task',18,'asdf adam qualification normal tasktypecrmopportunity 1397198983'),(29,'2014-04-11 16:49:53',NULL,1,NULL,'Task',19,'asdf adam qualification normal tasktypecrmopportunity 1397198993'),(30,'2014-04-11 16:49:54',NULL,1,NULL,'Task',20,'asdf adam qualification normal tasktypecrmopportunity 1397198994'),(31,'2014-04-11 16:49:57',NULL,1,NULL,'Task',21,'asdf adam qualification normal tasktypecrmopportunity 1397198997'),(32,'2014-04-11 16:49:58',NULL,1,NULL,'Task',22,'asdf adam qualification normal tasktypecrmopportunity 1397198998'),(33,'2014-04-11 16:50:10',NULL,1,NULL,'Task',23,'asdf adam qualification normal tasktypecrmopportunity 1397199010'),(34,'2014-04-11 16:50:11',NULL,1,NULL,'Task',24,'asdf adam qualification normal tasktypecrmopportunity 1397199011'),(35,'2014-04-11 16:50:13',NULL,1,NULL,'Task',25,'asdf adam qualification normal tasktypecrmopportunity 1397199013'),(36,'2014-04-11 16:50:25',NULL,1,NULL,'Task',26,'asdf adam qualification normal tasktypecrmopportunity 1397199025'),(37,'2014-04-11 16:50:32',NULL,1,NULL,'Task',27,'asdf adam qualification normal tasktypecrmopportunity 1397199032'),(38,'2014-04-11 16:50:45',NULL,1,NULL,'Task',28,'asdf adam qualification normal tasktypecrmopportunity 1397199045'),(39,'2014-04-11 16:50:45',NULL,1,NULL,'Task',29,'asdf adam qualification normal tasktypecrmopportunity 1397199045'),(40,'2014-04-11 16:50:50',NULL,1,NULL,'Task',30,'asdf adam qualification normal tasktypecrmopportunity 1397199050'),(41,'2014-04-11 16:51:06',NULL,1,NULL,'Task',31,'asdf adam qualification normal tasktypecrmopportunity 1397199066'),(42,'2014-04-11 16:51:17',NULL,1,NULL,'Task',32,'asdf adam qualification normal tasktypecrmopportunity 1397199077'),(43,'2014-04-11 16:51:26',NULL,1,NULL,'Task',33,'asdf adam qualification normal tasktypecrmopportunity 1397199086'),(44,'2014-04-11 16:51:47',NULL,1,NULL,'Task',34,'asdf adam qualification normal tasktypecrmopportunity 1397199107'),(45,'2014-04-11 16:53:02',NULL,1,NULL,'Task',35,'asdf adam qualification normal tasktypecrmopportunity 1397199182'),(46,'2014-04-11 16:54:43',NULL,1,NULL,'Task',36,'asdf adam qualification normal tasktypecrmopportunity 1397199283'),(47,'2014-04-11 16:54:43',NULL,1,NULL,'CrmOpportunity',1,'asdf 100 10.00 1398348000'),(48,'2014-04-11 16:54:43',NULL,1,NULL,'Task',37,'asdf adam qualification normal tasktypecrmopportunity 1397199283'),(49,'2014-04-11 16:54:43',NULL,1,NULL,'CrmOpportunity',2,'asdf 100 10.00 1398348000'),(50,'2014-04-11 16:54:43',NULL,1,NULL,'Task',38,'asdf adam qualification normal tasktypecrmopportunity 1397199283'),(51,'2014-04-11 16:54:43',NULL,1,NULL,'CrmOpportunity',3,'asdf 100 10.00 1398348000'),(52,'2014-04-11 16:54:43',NULL,1,NULL,'Task',39,'asdf adam qualification normal tasktypecrmopportunity 1397199283'),(53,'2014-04-11 16:54:43',NULL,1,NULL,'CrmOpportunity',4,'asdf 100 10.00 1398348000'),(54,'2014-04-11 16:54:43',NULL,1,NULL,'Task',40,'asdf adam qualification normal tasktypecrmopportunity 1397199283'),(55,'2014-04-11 16:54:43',NULL,1,NULL,'Task',41,'asdf adam qualification normal tasktypecrmopportunity 1397199283'),(56,'2014-04-11 16:54:43',NULL,1,NULL,'Task',42,'asdf adam qualification normal tasktypecrmopportunity 1397199283'),(57,'2014-04-11 16:54:43',NULL,1,NULL,'Task',43,'asdf adam qualification normal tasktypecrmopportunity 1397199283'),(58,'2014-04-11 16:54:43',NULL,1,NULL,'Task',44,'asdf adam qualification normal tasktypecrmopportunity 1397199283'),(59,'2014-04-11 16:54:43',NULL,1,NULL,'Task',45,'asdf adam qualification normal tasktypecrmopportunity 1397199283'),(61,'2014-04-14 14:12:30','2014-04-14 14:12:30',1,1,'Task',46,'crmform1 draft normal tasktypecrmquote 1397448750'),(62,'2014-04-14 14:13:46','2014-04-14 14:13:46',1,1,'Task',47,'crmform2 draft normal tasktypecrmquote 1397448826'),(63,'2014-04-14 14:20:30','2014-04-14 14:20:30',1,1,'Task',48,'crmform3 draft normal tasktypecrmquote 1397449230'),(64,'2014-04-14 14:20:42','2014-04-14 14:20:42',1,1,'Task',49,'crmform4 draft normal tasktypecrmquote 1397449242'),(65,'2014-04-14 14:21:58','2014-04-14 14:21:58',1,1,'CrmQuote',1,'1398607200'),(66,'2014-04-14 14:21:58','2014-04-14 14:21:58',1,1,'Task',50,'crmform5 draft normal tasktypecrmquote 1397449318'),(67,'2014-04-14 14:22:17','2014-04-14 14:22:17',1,1,'CrmQuote',2,'1398607200'),(68,'2014-04-14 14:22:17','2014-04-14 14:22:17',1,1,'Task',51,'crmform6 draft normal tasktypecrmquote 1397449337'),(70,'2014-04-14 14:22:23','2014-04-14 14:22:23',1,1,'Task',52,'crmform7 normal tasktypecrminvoice 1397449343'),(71,'2014-04-14 14:22:54','2014-04-14 14:22:54',1,1,'CrmInvoice',2,'invoice test'),(72,'2014-04-14 14:22:54','2014-04-14 14:22:54',1,1,'Task',53,'crmform8 normal tasktypecrminvoice 1397449374'),(73,'2014-04-14 14:24:34','2014-04-14 14:24:34',1,1,'CrmProject',1,'test 1396792800 1398780000'),(74,'2014-04-14 14:45:14','2014-04-14 14:45:14',1,1,'CrmExpense',1,'1397397600 100 9.090909090909092 expense payment kickstarter project credit card personal account'),(75,'2014-04-14 14:45:14','2014-04-14 14:45:14',1,1,'Task',54,'expense 100 normal tasktypecrmexpense 1397450714'),(76,'2014-04-23 15:16:13','2014-04-23 15:16:13',1,1,'CrmAccount',2,'test customer private company'),(77,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',3,'bunyip toys lead'),(78,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',4,'change agency zak sequoia customer http://thechangeagency.org/ thechangeagency.org'),(79,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',5,'bermagui seaview beachhouses customer http://seaviewbeachhouses.com.au/ seaviewbeachhouses.com.au'),(80,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',6,'pambula engineering customer'),(81,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',7,'marlo hotel customer http://www.marlohotel.com.au/'),(82,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',8,'community training partnerships customer http://communitytrainingpartnerships.org.au/ communitytrainingpartnerships.org.au'),(83,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',9,'department healthcooma lead'),(84,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',10,'mindfield lead sent via vickie, roger\'s partner. www.mindfield.com.au mindfield.com.au'),(85,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',11,'merimbula realty customer shop 3/11 drive nsw http://www.merimbularealty.com.au/ merimbularealty.com.au'),(86,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',12,'sapphire coast buslines customer nbsp scbuslines.com.au redfern close box 256 south pambula nsw'),(87,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',13,'bega valley shire council lead'),(88,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',14,'doug robertson draft engineering customer'),(89,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',15,'design central partner'),(90,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',16,'nullarbor consulting pty ltd customer box pambula nsw'),(91,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',17,'tanner salt lead http://tannersalt.com.au tannersalt.com.au'),(92,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',18,'magic mountain customer http://magicmountain.net.au magicmountain.net.au'),(93,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',19,'merimbula visitor information centre customer'),(94,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',20,'johnston marketing customer www.johmar.com.au'),(95,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',21,'barbara limited customer currently hosting carsten. soon moved tripleacs. http://stbarbara.com.au stbarbara.com.au level 10, 432 kilda road melbourne vic australia'),(96,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',22,'kanbanflow vendor'),(97,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',23,'google vendor'),(98,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',24,'crazy domains pty ltd vendor'),(99,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',25,'panthur pty ltd vendor'),(100,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',26,'hunter/aon insurances vendor'),(101,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',27,'qbe insurances vendor'),(102,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',28,'fuss bookkeeping vendor'),(103,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',29,'anz bank vendor'),(104,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',30,'zoho corporation vendor'),(105,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',31,'paul lewis data cabling vendor'),(106,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',32,'matt edebohl partner'),(107,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',33,'adam buckley partner developer'),(108,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',34,'yifan yang partner'),(109,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',35,'fred wood electrical vendor'),(110,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',36,'jason richards vendor support moruya, batemans bay'),(111,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',37,'merimbula jewellers customer contacted moving website hosting. http://www.merimbulajewellers.com.au'),(112,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',38,'splash internet lead'),(113,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',39,'medal art mint lead friend jamie shaw bega'),(114,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',40,'andrew breheny vendor electrical contractor'),(115,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',41,'jamie shaw customer author jdshaw.com.au'),(116,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',42,'andy brown photography customer rachel choy\'s partner'),(117,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',43,'andrea cuthbert customer'),(118,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',44,'micronet vendor crm system provider steeline. http://www.micronet.com.au'),(119,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',45,'natural regeneration australia pty ltd customer http://naturalregen.com.au'),(120,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',46,'neil burge tuscany apartments lead'),(121,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',47,'sapphire coast funerals customer coastnbspfuneralsnbspptyltdmunje street, pambula nsw 2549nbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbspnbsptelephone 6495 7077nbsp fax 7184 www.sapphirecoastfunerals.com.au'),(122,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',48,'club sapphire merimbula bowling lead currently sos customerreferred iain mckimm'),(123,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',49,'mont adventure equipment customer currently client darryl\'s. contact malware problem. http://mont.com.au pirie street fyshwick act australia'),(124,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',50,'tenants union act lead darryl\'s client. project javascript rent calculator. http://www.tenantsact.org.au/ box civic square australia'),(125,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',51,'robert green wheatfields lead owner office space throughout merimbula'),(126,'2014-04-23 15:32:55','2014-04-23 17:06:20',1,1,'CrmAccount',52,'365cups.com customer'),(127,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',53,'sapphire coast tourism customer www.sapphirecoast.com.au'),(128,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',54,'val morgan customer cinema advertising company provide entertainment shopping centers car washes, etc.carsten currently provides hosting services them, move tripleacs brand june months comes up. http://www.valmorgan.com.au valmorgan.com.au'),(129,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',55,'gottagetaway lead main merimbula south wales'),(130,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',56,'excell printing customer www.excellprint.com.au excellprint.com.au pambula'),(131,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',57,'conference complete lead'),(132,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',58,'steeline customer http://steelinetanks.com.au steeline.com.au bullara street pambula nsw australia'),(133,'2014-04-23 15:32:55','2014-04-23 15:32:55',1,1,'CrmAccount',59,'gooseboy partner'),(134,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',60,'merimbula chamber commerce customer http://ourmerimbula.com.au'),(135,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',61,'fuss accounting frmrly mountain accountin partner'),(136,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',62,'tech lead'),(137,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',63,'ngh environmental lead'),(138,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',64,'auswide customer'),(139,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',65,'merimbula fresh food lead'),(140,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',66,'airport services merimbula lead'),(141,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',67,'merimbula.com.au mark keltie lead'),(142,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',68,'ipv6 lead'),(143,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',69,'marshall tacheci real estate customer lamont st. bermagui nsw australia'),(144,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',70,'cool freight customer'),(145,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',71,'bega cheese customer'),(146,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',72,'austcom/webhive bega customer'),(147,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',73,'danius maragus customer'),(148,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',74,'mandeni customer mandeni.com.au 489 red hill road, bournda nsw'),(149,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',75,'enhanceu lead'),(150,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',76,'seo ninja gabriel manchuret partner'),(151,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',77,'bilby cnc customer'),(152,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',78,'sewacs customer sewacs.org.au'),(153,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',79,'pambula real estate simone ficht lead'),(154,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',80,'boardwalk art customer'),(155,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',81,'winds festival customer bermagui community centre street nsw'),(156,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',82,'birds nest customer cooma'),(157,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',83,'south coast auto centre goodyear/hertz customer scauto.com.au merimbula drive nsw australia'),(158,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',84,'twofold security lead'),(159,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',85,'seashells apartments michael dixon lead'),(160,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',86,'ispy iphone app lead'),(161,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',87,'tripleacs pty ltd partner'),(162,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',88,'pyramid power customer taking hosting flow.'),(163,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',89,'prestige classic cars lead'),(164,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',90,'tulgeen customer http://www.tulgeen.com.au tulgeen.com.au'),(165,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',91,'zoho corporation vendor'),(166,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',92,'saasu pty ltd vendor'),(167,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',93,'warcom pty ltd vendor'),(168,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',94,'onesaas pty ltd vendor'),(169,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',95,'airlan wireless partner'),(170,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',96,'sarah james lead'),(171,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',97,'workability customer'),(172,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',98,'bennet schwartz lead'),(173,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',99,'acora customer'),(174,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',100,'gem enviro customer suite unit 239 carp str bega nsw australia'),(175,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',101,'sapphire smiles customer unit palmer merimbula nsw'),(176,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',102,'solutions biz customer'),(177,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',103,'artifax partner'),(178,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',104,'smart consulting partner box 420, pambula nsw'),(179,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',105,'edge radio customer'),(180,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',106,'burwood clivia lead'),(181,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',107,'tathra beach family park lead'),(182,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',108,'redgumweb pty ltd partner'),(183,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',109,'bortoli wines customer debortoli.com.au'),(184,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',110,'mandala alchemy pty ltd partner'),(185,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',111,'boillat refrigeration vendor'),(186,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',112,'atlas life coastal wilderness alcw customer'),(187,'2014-04-23 15:32:56','2014-04-23 16:47:18',1,1,'CrmAccount',113,'daniel veterinary pambula customer bolara'),(188,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',114,'wesson stories inc pty ltd lead 140 upper heidelberg road ivanhoe vic australia'),(189,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',115,'mch welding bombala lead'),(190,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',116,'john mcdermott motors customer sir william mckell pambula'),(191,'2014-04-23 15:32:56','2014-04-23 15:32:56',1,1,'CrmAccount',117,'merimbula wharf aquarium lead'),(192,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',2,'andrew hellyer andrew@bunyiptoys.com.au bunyip toys'),(193,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',3,'zak sequoia 0456 924 695 zak@woodenpier.com change agency'),(194,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',4,'len slater 64921891 0437 385 018 lenandwendy@internode.on.net bermagui seaview beachhouses'),(195,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',5,'tom dawson 0412 880 471 tom.dawson@steeline.com.au steeline'),(196,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',6,'ruiz-avila sydney@akt-kix.com pambula engineering'),(197,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',7,'david girardeau 0407503182 ffdrafting@hotmail.com pambula engineering'),(198,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',8,'christiea@scbuslines.com.au sapphire coast buslines'),(199,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',9,'rachel jones 0429 910 317 rachel@scwl.org.au marlo hotel'),(200,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',10,'robert lockerbie 6492 6500 0423 812 962 robert.lockerbie@gmail.com'),(201,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',11,'shereene simpson 6495 3555 shereene@merimbularealty.com.au merimbula realty'),(202,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',12,'leanne atkinson 0414 417 315 leanneatkinson1@gmail.com community training partnerships'),(203,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',13,'robyn lunt 64553361 sapphire coast buslines'),(204,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',14,'trent pool trent@merimbularealty.com.au merimbula realty'),(205,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',15,'bev parker bev@merimbularealty.com.au merimbula realty'),(206,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',16,'scott glendinning 9381 3311 0407 755 190 sg@mindfield.com.au mindfield'),(207,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',17,'joint business owner jon kelly 6495 3026 0428 954 662 jon@merimbularealty.com.au merimbula realty'),(208,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',18,'paul judd 6495 6452 paulj@scbuslines.com.au sapphire coast buslines'),(209,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',19,'jamie klemm 6495 6452 jamiek@scbuslines.com.au sapphire coast buslines'),(210,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',20,'bob mcalister bmcalister@begavalley.nsw.gov.au bega valley shire council'),(211,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',21,'doug robertson 0488242488 douglasjames.au@gmail.com draft engineering'),(212,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',22,'meredith lyons meredith@designcentral.com.au design central'),(213,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',23,'belinda nunn belinda@tannersalt.com.au tanner salt'),(214,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',24,'karen machan karen.machan@tulgeen.com.au tulgeen'),(215,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',25,'jen taylor jen.taylor@tulgeen.com.au tulgeen'),(216,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',26,'heather buckland heather.buckland@tulgeen.com.au tulgeen'),(217,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',27,'lesley minto lesley.minto@tulgeen.com.au tulgeen'),(218,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',28,'taryn beesley 6492 3222 taryn.beesley@workability.net.au workability'),(219,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',29,'elaine philips 0419 408 902 magic mountain'),(220,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',30,'merrilie insch 64952299 0448019537 fun@magicmountain.net.au magic mountain'),(221,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',31,'administrator administrator@tulgeen.com.au tulgeen'),(222,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',32,'joanne mcnamara joanne.mcnamara@tulgeen.com.au tulgeen'),(223,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',33,'kevin gerathy 64951216 0411540090 office@beachcabins.com.au merimbula visitor information centre'),(224,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',34,'dave sparks 0400027545 piratestudios@yahoo.com.au'),(225,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',35,'carey dessaix 0405 305 198 carey@dessaix.com'),(226,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',36,'gae rheinberger 0409 463 709 gae.rheinberger@tulgeen.com.au tulgeen'),(227,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',37,'kass fenton kass.fenton@tulgeen.com.au tulgeen'),(228,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',38,'gary johnston 0411 598801 gary@johmar.com.au marketing'),(229,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',39,'rachel choy rachel.choy@tulgeen.com.au tulgeen'),(230,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',40,'dianne rees dianne.rees@tulgeen.com.au tulgeen'),(231,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',41,'kristi sproates kristi.sproates@tulgeen.com.au tulgeen'),(232,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',42,'sue hartemink 0421414476 sue.hartemink@tulgeen.com.au tulgeen'),(233,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',43,'edward jeffries 8660 1972 0448 504 440 edward.jeffries@stbarbara.com.au barbara limited'),(234,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',44,'julian kemp 8660 1920 0407 552 588 julian.kemp@stbarbara.com.au barbara limited'),(235,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',45,'mitch van reesch mitch.van.reesch@tulgeen.com.au tulgeen'),(236,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',46,'accounts accpay@debortoli.com.au bortoli wines'),(237,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',47,'paul spiteri 64990807 paul.spiteri@tulgeen.com.au tulgeen'),(238,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',48,'sarah spurling sarah.spurling@tulgeen.com.au tulgeen'),(239,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',49,'nick machan nick.machan@tulgeen.com.au tulgeen'),(240,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',50,'kylie furnell 6492 3944 0427 771927 kylief@auswideprojects.org.au auswide'),(241,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',51,'carste eckelmann 0458795544 carsten.eckelmann@tulgeen.com.au tulgeen'),(242,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',52,'natalie godward 0434058871 natalie@merimbulajewellers.com.au merimbula jewellers'),(243,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',53,'paul mccooey 0410 468 890 admin@splashinternet.net.org splash internet'),(244,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',54,'address...back spiral gallery bega tony dean info@medalartmint.com medal art mint'),(245,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',55,'andrew breheny 0428720867 andrewbreheny@hotmail.com'),(246,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',56,'jamie shaw 0427227083 jamie@jdshaw.com.au'),(247,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',57,'rachel choy rachel@abphotography.com.au andy brown photography'),(248,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',58,'andrea cuthbert 0402242163 andrea.cuthbert@tulgeen.com.au'),(249,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',59,'technical consultant micronet john hobbes 9542 2000'),(250,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',60,'josh dorrough 6494 2744 josh.dorrough@naturalregen.com.au natural regeneration australia pty ltd'),(251,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',61,'munje pambula brenda 6495 7077 scfscf@bigpond.com sapphire coast funerals'),(252,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',62,'damian foley dfoley@clubsapphire.com.au club sapphire merimbula bowling'),(253,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',63,'manager receiver quotes/invoices deb pippen 6247 1026 debp@tenantsact.org.au tenants union act'),(254,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',64,'tenancy advisor/ project worker main contact work. adelaide rief 6247 1026 adelaider@tenantsact.org.au tenants union act'),(255,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',65,'director david edwards 6162 0900 oscar@mont.com.au mont adventure equipment'),(256,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',66,'nick graham-higgs 0427 260 819 nick.gh@nghenvironmental.com.au ngh environmental'),(257,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',67,'robert green 6282 2667 0402 647 040 robert@wheatfields.com.au wheatfields'),(258,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',68,'rose hulst 0438 924 151 rose.hulst@tulgeen.com.au tulgeen'),(259,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',69,'peter gorton peter.gorton@tulgeen.com.au tulgeen'),(260,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',70,'bill robertson 660 100 billrobertson@debortoli.com.au bortoli wines'),(261,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',71,'simone eyles simone@365cups.com 365cups.com'),(262,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',72,'anthony osborne 0428 243 539 aosborne@sapphirecoast.com.au sapphire coast tourism'),(263,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',73,'anthony marshall 6455 7552 anthony@birdsnest.com.au birds nest'),(264,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',74,'paul butler main contact projects val morgan. 8113 5600 0402 415 788 pbutler@valmorgan.com.au morgan'),(265,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',75,'org dev co-ord shane ardern 6499 0805 0435 055 405 shane.ardern@tulgeen.com.au tulgeen'),(266,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',76,'yifan yang 0425 209 736 yang.yifan0@gmail.com'),(267,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',77,'stephen garrett 0410047122 stephen@pyramidpower.com.au pyramid power'),(268,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',78,'paul boillat 0458855768 paulboillat@internode.on.net refrigeration'),(269,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',79,'helene garrett 0428 590 084 helene@pyramidpower.com.au pyramid power'),(270,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',80,'don peterson donp@fnfc.com.au gottagetaway'),(271,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',81,'thorpe jo.thorpe@fnfc.com.au gottagetaway'),(272,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',82,'andy willis 6499 0651 408 923 599 andy@conferencecomplete.com.au conference complete'),(273,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',83,'neil dawson 6495 6968 0411 440 331 neil.dawson@steeline.com.au steeline'),(274,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',84,'brent occleshaw 6494 2133 0419 358 834 brent@gooseboy.tv gooseboy'),(275,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',85,'natalie godward 0434 058 871 natalie@ourmerimbula.com.au merimbula chamber commerce'),(276,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',86,'alan mogridge 6495 7320 alan@excellprint.com.au excell printing'),(277,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',87,'stephen cotteril 6458 4481 info@mountainaccountin.com.au fuss accounting frmrly mountain accountin'),(278,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',88,'sak ryopponen 0409353894 sak1@iprimus.com.au tech'),(279,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',89,'greg coram 0448000477 greg.c@nghenvironmental.com.au ngh environmental'),(280,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',90,'kerry nicholls 0264941561 0429959187 austinfinance@bigpond.com.au'),(281,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',91,'debbie isles merimbulafreshfood@bigpond.com merimbula fresh food'),(282,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',92,'mick hoorweg mick@switchthree.com danius maragus'),(283,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',93,'mark keltie merimbula.com.au'),(284,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',94,'karl auer 0428 957 160 kauer@nullarbor.com.au nullarbor consulting pty ltd'),(285,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',95,'robert tacheci 0407 934160 robert@marshallandtacheci.com.au marshall real estate'),(286,'2014-04-23 16:46:58','2014-04-23 16:46:58',1,1,'CrmContact',96,'dave wilson 6458 4191 0408587211 djcoolfreight@bigpond.com cool freight'),(287,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',97,'iain mckimm iain.mckimm@begacheese.com.au bega cheese'),(288,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',98,'geoffrey grigg 64925000 0499 302 688 austcom/webhive bega'),(289,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',99,'jackie stallard 44768001 0447 698 874 jackie@austcom.org.au austcom/webhive bega'),(290,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',100,'steve jenni jory 6495 3577 0428 425 759 jenni@enhanceu.com.au enhanceu'),(291,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',101,'gabriel manchuret 8003 5188 0419585863 nitrogendreams@gmail.com seo ninja'),(292,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',102,'lee bilby 1800 245 297 0478 671 131 lee@bilby.net cnc'),(293,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',103,'sylvia morrah 6492 3597 0448 536 117 sylvia.morrah@sewacs.org.au sewacs'),(294,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',104,'simone ficht 0403 336 099 simone.ficht@yahoo.com.au'),(295,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',105,'tracy creighton 6495 4608 boardwalkart@internode.on.net boardwalk art'),(296,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',106,'rob 6495 9785 rob@mandeni.com.au mandeni'),(297,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',107,'paul williams 6495 34444 0429 434 670 paul@scauto.com.au south coast auto centre goodyear/hertz'),(298,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',108,'tess williams tess@scauto.com.au south coast auto centre goodyear/hertz'),(299,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',109,'manager larry oakley 6494 3232 0428 649 573 twofoldsecurity@dragnet.com.au twofold security'),(300,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',110,'pat neville 6494 3232 0488 970 004 twofoldadmin@upnet.net.au twofold security'),(301,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',111,'carsten eckelmann carsten@tripleacs.com tripleacs pty ltd'),(302,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',112,'paul bailey 6495 7216 pbaileysprojects@gmail.com ispy iphone app'),(303,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',113,'penny amberg 0448 129 420 penny@fourwinds.com.au winds festival'),(304,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',114,'adam thomas adam@prestigeclassiccars.com.au prestige classic cars'),(305,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',115,'armen gregorian 0414262614 agregorian@airlan.com.au airlan wireless'),(306,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',116,'sarah james 6498 5258 0424 918 566 pipeldoot.en.voiture@gmail.com'),(307,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',117,'terry terry@fourwinds.com.au winds festival'),(308,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',118,'liam o\'duibhir 0417579079 liam@tripleacs.com tripleacs pty ltd'),(309,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',119,'bennet schwartz bennets87@gmail.com'),(310,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',120,'administrator june boulton acora'),(311,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',121,'manager roger timms rtimms@acora.com.au acora'),(312,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',122,'john turville 0416125418 jturville1@gmail.com gem enviro'),(313,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',123,'email -nbspamandaalexander44@hotmail.comold -nbspsmiles@merimbula-ortho.com.au mandy amanda alexander 6495 4255 0430 962 966 smiles@sapphiresmiles.com.au sapphire smiles'),(314,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',124,'goodlock 6492 3222 jo.goodlock@workability.net.au workability'),(315,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',125,'nigel ayling 0412 463 386 nigel@solutions4.biz solutions biz'),(316,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',126,'dave elliot 6499 0803 0458 920 000 dave.elliott@tulgeen.com.au tulgeen'),(317,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',127,'avon rollason 6499 0802 0407 296 507 avon.rollason@tulgeen.com.au tulgeen'),(318,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',128,'jon oakes jon.oakes@artifax.com.au artifax'),(319,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',129,'jon oakes jon.oakes@get-smart.com.au smart consulting'),(320,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',130,'grant keogh sapphire smiles'),(321,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',131,'chris sheedy 0420578746 cbsheedy@gmail.com edge radio'),(322,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',132,'cheryl nelson 6492 3597 0411 172 447 cheryl.nelson@sewacs.org.au sewacs'),(323,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',133,'jane mckinnon manager@tbfp.com.au tathra beach family park'),(324,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',134,'frank holden tathra beach family park'),(325,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',135,'symony douglas 0416398952 symonyj@hotmail.com mandeni'),(326,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',136,'caroline 6492 2223 0428 136 196 caroline.long@bwr.org.au sewacs'),(327,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',137,'roger bunyan 6492 7202 0419 424 829 roger@redgumweb.com.au redgumweb pty ltd'),(328,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',138,'darryl butler darryl@itchybrain.com.au mandala alchemy pty ltd'),(329,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',139,'chris bilby 0431 089 143 chris@bilby.net cnc'),(330,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',140,'libby hepburn 0458 798 990 libby.alanhepburn@bigpond.com atlas life coastal wilderness alcw'),(331,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',141,'linden daniel 0427 186 633 danielvets@hotmail.com veterinary pambula'),(332,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',142,'justin daniel 0427 771 424 veterinary pambula'),(333,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',143,'brenda daly dalby@netspace.net.au wesson stories inc pty ltd'),(334,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',144,'malcolm hurley mch welding bombala'),(335,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',145,'belinda hurley 026458 4700 mchweld@bigpond.net.au mch welding bombala'),(336,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',146,'anthony daly 0411 090 420 nindaly@bigpond.com merimbula wharf aquarium'),(337,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',147,'john mcdermott 6495 6147 motors'),(338,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',148,'cath turville 0409 153 964 cath@gemenviro.com.au gem enviro'),(339,'2014-04-23 16:46:59','2014-04-23 16:46:59',1,1,'CrmContact',149,'janine mcdermott 0428949144 jm.auto@bigpond.com john motors');
/*!40000 ALTER TABLE `object_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_modification`
--

DROP TABLE IF EXISTS `object_modification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `object_modification` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `table_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `object_id` bigint(20) NOT NULL,
  `dt_created` datetime DEFAULT NULL,
  `dt_modified` datetime DEFAULT NULL,
  `creator_id` bigint(20) DEFAULT NULL,
  `modifier_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_modification`
--

LOCK TABLES `object_modification` WRITE;
/*!40000 ALTER TABLE `object_modification` DISABLE KEYS */;
INSERT INTO `object_modification` VALUES (2,'task_group',2,'2014-04-11 16:16:01',NULL,1,NULL),(3,'task',1,'2014-04-11 16:39:40',NULL,1,NULL),(4,'task',2,'2014-04-11 16:39:47',NULL,1,NULL),(5,'task',3,'2014-04-11 16:39:58',NULL,1,NULL),(6,'task',4,'2014-04-11 16:40:54',NULL,1,NULL),(7,'task',5,'2014-04-11 16:45:41',NULL,1,NULL),(8,'task',6,'2014-04-11 16:45:50',NULL,1,NULL),(9,'task',7,'2014-04-11 16:46:38',NULL,1,NULL),(10,'task',8,'2014-04-11 16:46:44',NULL,1,NULL),(11,'task',9,'2014-04-11 16:47:09',NULL,1,NULL),(12,'task',10,'2014-04-11 16:47:32',NULL,1,NULL),(13,'task',11,'2014-04-11 16:48:14',NULL,1,NULL),(14,'task',12,'2014-04-11 16:48:26',NULL,1,NULL),(15,'task',13,'2014-04-11 16:48:29',NULL,1,NULL),(16,'task',14,'2014-04-11 16:48:44',NULL,1,NULL),(17,'task',15,'2014-04-11 16:49:04',NULL,1,NULL),(18,'task',16,'2014-04-11 16:49:16',NULL,1,NULL),(19,'task',17,'2014-04-11 16:49:42',NULL,1,NULL),(20,'task',18,'2014-04-11 16:49:43',NULL,1,NULL),(21,'task',19,'2014-04-11 16:49:53',NULL,1,NULL),(22,'task',20,'2014-04-11 16:49:54',NULL,1,NULL),(23,'task',21,'2014-04-11 16:49:57',NULL,1,NULL),(24,'task',22,'2014-04-11 16:49:58',NULL,1,NULL),(25,'task',23,'2014-04-11 16:50:10',NULL,1,NULL),(26,'task',24,'2014-04-11 16:50:11',NULL,1,NULL),(27,'task',25,'2014-04-11 16:50:13',NULL,1,NULL),(28,'task',26,'2014-04-11 16:50:25',NULL,1,NULL),(29,'task',27,'2014-04-11 16:50:32',NULL,1,NULL),(30,'task',28,'2014-04-11 16:50:45',NULL,1,NULL),(31,'task',29,'2014-04-11 16:50:45',NULL,1,NULL),(32,'task',30,'2014-04-11 16:50:50',NULL,1,NULL),(33,'task',31,'2014-04-11 16:51:06',NULL,1,NULL),(34,'task',32,'2014-04-11 16:51:17',NULL,1,NULL),(35,'task',33,'2014-04-11 16:51:26',NULL,1,NULL),(36,'task',34,'2014-04-11 16:51:47',NULL,1,NULL),(37,'task',35,'2014-04-11 16:53:02',NULL,1,NULL),(38,'task',36,'2014-04-11 16:54:43',NULL,1,NULL),(39,'task',37,'2014-04-11 16:54:43',NULL,1,NULL),(40,'task',38,'2014-04-11 16:54:43',NULL,1,NULL),(41,'task',39,'2014-04-11 16:54:43',NULL,1,NULL),(42,'task',40,'2014-04-11 16:54:43',NULL,1,NULL),(43,'task',41,'2014-04-11 16:54:43',NULL,1,NULL),(44,'task',42,'2014-04-11 16:54:43',NULL,1,NULL),(45,'task',43,'2014-04-11 16:54:43',NULL,1,NULL),(46,'task',44,'2014-04-11 16:54:43',NULL,1,NULL),(47,'task',45,'2014-04-11 16:54:43',NULL,1,NULL),(48,'task_group',3,'2014-04-14 14:12:30','2014-04-14 14:12:30',1,1),(49,'task',46,'2014-04-14 14:12:30','2014-04-14 14:12:30',1,1),(50,'task',47,'2014-04-14 14:13:46','2014-04-14 14:13:46',1,1),(51,'task',48,'2014-04-14 14:20:30','2014-04-14 14:20:30',1,1),(52,'task',49,'2014-04-14 14:20:42','2014-04-14 14:20:42',1,1),(53,'task',50,'2014-04-14 14:21:58','2014-04-14 14:21:58',1,1),(54,'task',51,'2014-04-14 14:22:17','2014-04-14 14:22:17',1,1),(55,'task_group',4,'2014-04-14 14:22:23','2014-04-14 14:22:23',1,1),(56,'task',52,'2014-04-14 14:22:23','2014-04-14 14:22:23',1,1),(57,'task',53,'2014-04-14 14:22:54','2014-04-14 14:22:54',1,1),(58,'task_group',5,'2014-04-14 14:30:12','2014-04-14 14:30:12',1,1),(59,'task_group',6,'2014-04-14 14:45:14','2014-04-14 14:45:14',1,1),(60,'task',54,'2014-04-14 14:45:14','2014-04-14 14:45:14',1,1);
/*!40000 ALTER TABLE `object_modification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `printer`
--

DROP TABLE IF EXISTS `printer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `printer` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  `server` varchar(512) NOT NULL,
  `port` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `printer`
--

LOCK TABLES `printer` WRITE;
/*!40000 ALTER TABLE `printer` DISABLE KEYS */;
/*!40000 ALTER TABLE `printer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report`
--

DROP TABLE IF EXISTS `report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_connection_id` bigint(20) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `module` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `report_code` text COLLATE utf8_unicode_ci NOT NULL,
  `is_approved` tinyint(1) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `description` text COLLATE utf8_unicode_ci,
  `sqltype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report`
--

LOCK TABLES `report` WRITE;
/*!40000 ALTER TABLE `report` DISABLE KEYS */;
INSERT INTO `report` VALUES (1,NULL,'Audit','admin','','[[dt_from||date||Date From]]\r\n\r\n[[dt_to||date||Date To]]\r\n\r\n[[user_id||select||User||select u.id as value, concat(c.firstname,\' \',c.lastname) as title from user u, contact c where u.contact_id = c.id order by title]]\r\n\r\n[[module||select||Module||select distinct module as value, module as title from audit order by module asc]]\r\n\r\n[[action||select||Action||select distinct action as value, concat(module,\'/\',action) as title from audit order by title]]\r\n\r\n@@Audit Report||\r\n\r\nselect \r\na.dt_created as Date, \r\nconcat(c.firstname,\' \',c.lastname) as User,  \r\na.module as Module,\r\na.path as Url,\r\na.db_class as \'Class\',\r\na.db_action as \'Action\',\r\na.db_id as \'DB Id\'\r\n\r\nfrom audit a\r\n\r\nleft join user u on u.id = a.creator_id\r\nleft join contact c on c.id = u.contact_id\r\n\r\nwhere \r\na.dt_created >= \'{{dt_from}} 00:00:00\' \r\nand a.dt_created <= \'{{dt_to}} 23:59:59\' \r\nand (\'{{module}}\' = \'\' or a.module = \'{{module}}\')\r\nand (\'{{action}}\' = \'\' or a.action = \'{{action}}\') \r\nand (\'{{user_id}}\' = \'\' or a.creator_id = \'{{user_id}}\')\r\n\r\n@@\r\n',1,0,'Show Audit Information','select'),(2,NULL,'Contacts','admin','','@@Contacts||\r\nselect * from contact\r\n@@',0,0,'','select');
/*!40000 ALTER TABLE `report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_connection`
--

DROP TABLE IF EXISTS `report_connection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_connection` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `db_driver` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `db_host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `db_port` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `db_database` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `db_file` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `s_db_user` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `s_db_password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `creator_id` bigint(20) DEFAULT NULL,
  `modifier_id` bigint(20) DEFAULT NULL,
  `dt_created` datetime NOT NULL,
  `dt_modified` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_connection`
--

LOCK TABLES `report_connection` WRITE;
/*!40000 ALTER TABLE `report_connection` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_connection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_feed`
--

DROP TABLE IF EXISTS `report_feed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_feed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(1024) COLLATE utf8_unicode_ci NOT NULL,
  `dt_created` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_feed`
--

LOCK TABLES `report_feed` WRITE;
/*!40000 ALTER TABLE `report_feed` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_feed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_member`
--

DROP TABLE IF EXISTS `report_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_member`
--

LOCK TABLES `report_member` WRITE;
/*!40000 ALTER TABLE `report_member` DISABLE KEYS */;
INSERT INTO `report_member` VALUES (1,1,1,'OWNER',0),(2,2,1,'OWNER',0);
/*!40000 ALTER TABLE `report_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rest_session`
--

DROP TABLE IF EXISTS `rest_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rest_session` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `token` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `dt_created` datetime NOT NULL,
  `dt_modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rest_session`
--

LOCK TABLES `rest_session` WRITE;
/*!40000 ALTER TABLE `rest_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `rest_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `session_id` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `session_data` text COLLATE utf8_unicode_ci NOT NULL,
  `expires` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task`
--

DROP TABLE IF EXISTS `task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_closed` tinyint(1) NOT NULL DEFAULT '0',
  `parent_id` int(11) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `task_group_id` int(11) NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `priority` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `task_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `assignee_id` int(11) NOT NULL,
  `dt_assigned` datetime NOT NULL,
  `dt_first_assigned` datetime NOT NULL,
  `first_assignee_id` int(11) NOT NULL,
  `dt_completed` datetime DEFAULT NULL,
  `dt_planned` datetime DEFAULT NULL,
  `dt_due` datetime DEFAULT NULL,
  `estimate_hours` int(11) DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `latitude` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitude` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task`
--

LOCK TABLES `task` WRITE;
/*!40000 ALTER TABLE `task` DISABLE KEYS */;
INSERT INTO `task` VALUES (1,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:39:40','2014-04-11 16:39:40',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(2,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:39:47','2014-04-11 16:39:47',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(3,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:39:58','2014-04-11 16:39:58',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(4,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:40:54','2014-04-11 16:40:54',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(5,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:45:41','2014-04-11 16:45:41',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(6,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:45:50','2014-04-11 16:45:50',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(7,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:46:38','2014-04-11 16:46:38',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(8,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:46:44','2014-04-11 16:46:44',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(9,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:47:09','2014-04-11 16:47:09',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(10,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:47:32','2014-04-11 16:47:32',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(11,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:48:14','2014-04-11 16:48:14',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(12,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:48:26','2014-04-11 16:48:26',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(13,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:48:29','2014-04-11 16:48:29',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(14,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:48:44','2014-04-11 16:48:44',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(15,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:49:04','2014-04-11 16:49:04',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(16,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:49:16','2014-04-11 16:49:16',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(17,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:49:42','2014-04-11 16:49:42',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(18,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:49:43','2014-04-11 16:49:43',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(19,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:49:53','2014-04-11 16:49:53',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(20,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:49:54','2014-04-11 16:49:54',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(21,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:49:57','2014-04-11 16:49:57',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(22,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:49:58','2014-04-11 16:49:58',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(23,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:50:10','2014-04-11 16:50:10',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(24,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:50:11','2014-04-11 16:50:11',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(25,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:50:13','2014-04-11 16:50:13',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(26,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:50:25','2014-04-11 16:50:25',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(27,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:50:32','2014-04-11 16:50:32',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(28,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:50:45','2014-04-11 16:50:45',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(29,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:50:45','2014-04-11 16:50:45',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(30,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:50:50','2014-04-11 16:50:50',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(31,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:51:06','2014-04-11 16:51:06',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(32,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:51:17','2014-04-11 16:51:17',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(33,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:51:26','2014-04-11 16:51:26',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(34,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:51:47','2014-04-11 16:51:47',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(35,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:53:02','2014-04-11 16:53:02',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(36,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:54:43','2014-04-11 16:54:43',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(37,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:54:43','2014-04-11 16:54:43',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(38,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:54:43','2014-04-11 16:54:43',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(39,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:54:43','2014-04-11 16:54:43',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(40,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:54:43','2014-04-11 16:54:43',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(41,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:54:43','2014-04-11 16:54:43',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(42,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:54:43','2014-04-11 16:54:43',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(43,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:54:43','2014-04-11 16:54:43',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(44,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:54:43','2014-04-11 16:54:43',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(45,0,NULL,'asdf (Adam)',2,'Qualification','Normal','TaskType_CrmOpportunity',1,'2014-04-11 16:54:43','2014-04-11 16:54:43',1,NULL,NULL,NULL,NULL,'<ul><li>asdf</li></ul>',NULL,NULL,0),(46,0,NULL,'CrmForm[1]',3,'Draft','Normal','TaskType_CrmQuote',1,'2014-04-14 14:12:30','2014-04-14 14:12:30',1,NULL,NULL,NULL,NULL,'',NULL,NULL,0),(47,0,NULL,'CrmForm[2]',3,'Draft','Normal','TaskType_CrmQuote',1,'2014-04-14 14:13:46','2014-04-14 14:13:46',1,NULL,NULL,NULL,NULL,'',NULL,NULL,0),(48,0,NULL,'CrmForm[3]',3,'Draft','Normal','TaskType_CrmQuote',1,'2014-04-14 14:20:30','2014-04-14 14:20:30',1,NULL,NULL,NULL,NULL,'',NULL,NULL,0),(49,0,NULL,'CrmForm[4]',3,'Draft','Normal','TaskType_CrmQuote',1,'2014-04-14 14:20:42','2014-04-14 14:20:42',1,NULL,NULL,NULL,NULL,'',NULL,NULL,0),(50,0,NULL,'CrmForm[5]',3,'Draft','Normal','TaskType_CrmQuote',1,'2014-04-14 14:21:58','2014-04-14 14:21:58',1,NULL,NULL,NULL,NULL,'',NULL,NULL,0),(51,0,NULL,'CrmForm[6]',3,'Draft','Normal','TaskType_CrmQuote',1,'2014-04-14 14:22:17','2014-04-14 14:22:17',1,NULL,NULL,NULL,NULL,'',NULL,NULL,0),(52,0,NULL,'CrmForm[7]',4,'New','Normal','TaskType_CrmInvoice',1,'2014-04-14 14:22:23','2014-04-14 14:22:23',1,NULL,NULL,NULL,NULL,'',NULL,NULL,0),(53,0,NULL,'CrmForm[8]',4,'New','Normal','TaskType_CrmInvoice',1,'2014-04-14 14:22:54','2014-04-14 14:22:54',1,NULL,NULL,NULL,NULL,'',NULL,NULL,0),(54,0,NULL,' Other Expense $100',6,'New','Normal','TaskType_CrmExpense',1,'2014-04-14 14:45:14','2014-04-14 14:45:14',1,NULL,NULL,NULL,NULL,'',NULL,NULL,0);
/*!40000 ALTER TABLE `task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_data`
--

DROP TABLE IF EXISTS `task_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `key` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_data`
--

LOCK TABLES `task_data` WRITE;
/*!40000 ALTER TABLE `task_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_group`
--

DROP TABLE IF EXISTS `task_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `can_assign` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `can_view` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `can_create` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL,
  `is_deleted` tinyint(4) NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `task_group_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `default_assignee_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_group`
--

LOCK TABLES `task_group` WRITE;
/*!40000 ALTER TABLE `task_group` DISABLE KEYS */;
INSERT INTO `task_group` VALUES (2,'CRM Opportunities','OWNER','OWNER','OWNER',1,0,'Opportunities','TaskGroupType_CrmOpportunity',1),(3,'CRM Quotes','OWNER','OWNER','OWNER',1,0,'Quotes','TaskGroupType_CrmQuote',1),(4,'CRM Invoices','OWNER','OWNER','OWNER',1,0,'Invoices','TaskGroupType_CrmInvoice',1),(5,'1025 - Test','OWNER','OWNER','OWNER',1,0,'','TaskGroupType_CrmQuote',1),(6,'CRM Expenses','OWNER','OWNER','OWNER',1,0,'Expenses','TaskGroupType_CrmExpense',1);
/*!40000 ALTER TABLE `task_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_group_member`
--

DROP TABLE IF EXISTS `task_group_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_group_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_group_id` int(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `priority` int(11) NOT NULL,
  `is_active` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_group_member`
--

LOCK TABLES `task_group_member` WRITE;
/*!40000 ALTER TABLE `task_group_member` DISABLE KEYS */;
INSERT INTO `task_group_member` VALUES (2,2,1,'OWNER',1,1),(3,3,1,'OWNER',1,1),(4,4,1,'OWNER',1,1),(5,5,1,'OWNER',1,1),(6,6,1,'OWNER',1,1);
/*!40000 ALTER TABLE `task_group_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_group_notify`
--

DROP TABLE IF EXISTS `task_group_notify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_group_notify` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_group_id` int(11) NOT NULL,
  `role` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_group_notify`
--

LOCK TABLES `task_group_notify` WRITE;
/*!40000 ALTER TABLE `task_group_notify` DISABLE KEYS */;
INSERT INTO `task_group_notify` VALUES (7,2,'guest','creator',1),(8,2,'member','creator',1),(9,2,'member','assignee',1),(10,2,'owner','creator',1),(11,2,'owner','assignee',1),(12,2,'owner','other',1),(13,3,'guest','creator',1),(14,3,'member','creator',1),(15,3,'member','assignee',1),(16,3,'owner','creator',1),(17,3,'owner','assignee',1),(18,3,'owner','other',1),(19,4,'guest','creator',1),(20,4,'member','creator',1),(21,4,'member','assignee',1),(22,4,'owner','creator',1),(23,4,'owner','assignee',1),(24,4,'owner','other',1),(25,5,'guest','creator',1),(26,5,'member','creator',1),(27,5,'member','assignee',1),(28,5,'owner','creator',1),(29,5,'owner','assignee',1),(30,5,'owner','other',1),(31,6,'guest','creator',1),(32,6,'member','creator',1),(33,6,'member','assignee',1),(34,6,'owner','creator',1),(35,6,'owner','assignee',1),(36,6,'owner','other',1);
/*!40000 ALTER TABLE `task_group_notify` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_group_user_notify`
--

DROP TABLE IF EXISTS `task_group_user_notify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_group_user_notify` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `task_group_id` int(11) NOT NULL,
  `role` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` tinyint(1) DEFAULT '0',
  `task_creation` tinyint(1) NOT NULL DEFAULT '0',
  `task_details` tinyint(1) NOT NULL DEFAULT '0',
  `task_comments` tinyint(1) NOT NULL DEFAULT '0',
  `time_log` tinyint(1) NOT NULL DEFAULT '0',
  `task_documents` tinyint(1) NOT NULL DEFAULT '0',
  `task_pages` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_group_user_notify`
--

LOCK TABLES `task_group_user_notify` WRITE;
/*!40000 ALTER TABLE `task_group_user_notify` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_group_user_notify` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_object`
--

DROP TABLE IF EXISTS `task_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_object` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `table_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `object_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_object`
--

LOCK TABLES `task_object` WRITE;
/*!40000 ALTER TABLE `task_object` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_time`
--

DROP TABLE IF EXISTS `task_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_time` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `creator_id` int(11) NOT NULL,
  `dt_created` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `dt_start` datetime NOT NULL,
  `dt_end` datetime NOT NULL,
  `comment_id` int(11) NOT NULL,
  `is_suspect` tinyint(4) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_time`
--

LOCK TABLES `task_time` WRITE;
/*!40000 ALTER TABLE `task_time` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_time` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_user_notify`
--

DROP TABLE IF EXISTS `task_user_notify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_user_notify` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `task_id` int(11) NOT NULL,
  `task_creation` tinyint(1) NOT NULL DEFAULT '0',
  `task_details` tinyint(1) NOT NULL DEFAULT '0',
  `task_comments` tinyint(1) NOT NULL DEFAULT '0',
  `time_log` tinyint(1) NOT NULL DEFAULT '0',
  `task_documents` tinyint(1) NOT NULL DEFAULT '0',
  `task_pages` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_user_notify`
--

LOCK TABLES `task_user_notify` WRITE;
/*!40000 ALTER TABLE `task_user_notify` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_user_notify` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `template`
--

DROP TABLE IF EXISTS `template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `template` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `module` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template_title` text COLLATE utf8_unicode_ci,
  `template_body` longtext COLLATE utf8_unicode_ci,
  `test_title_json` text COLLATE utf8_unicode_ci,
  `test_body_json` text COLLATE utf8_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dt_created` datetime DEFAULT NULL,
  `dt_modified` datetime DEFAULT NULL,
  `creator_id` bigint(20) DEFAULT NULL,
  `modifier_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template`
--

LOCK TABLES `template` WRITE;
/*!40000 ALTER TABLE `template` DISABLE KEYS */;
/*!40000 ALTER TABLE `template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `login` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_salt` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_id` bigint(20) DEFAULT NULL,
  `password_reset_token` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dt_password_reset_at` timestamp NULL DEFAULT NULL,
  `redirect_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'main/index',
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_group` tinyint(4) NOT NULL,
  `dt_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dt_lastlogin` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','45562e358fe86203d5eb1931a0020c68f2715801','1784eb346d7987356b1a5f8b9b0e94a6',1,NULL,NULL,'main/index',1,1,0,0,'2012-04-26 20:31:07','2014-04-23 13:15:31');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `role` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_role_per_user` (`user_id`,`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_role`
--

LOCK TABLES `user_role` WRITE;
/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widget_config`
--

DROP TABLE IF EXISTS `widget_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widget_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `destination_module` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `source_module` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `widget_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `creator_id` bigint(20) NOT NULL,
  `custom_config` text COLLATE utf8_unicode_ci,
  `modifier_id` bigint(20) NOT NULL,
  `dt_created` datetime NOT NULL,
  `dt_modified` datetime NOT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widget_config`
--

LOCK TABLES `widget_config` WRITE;
/*!40000 ALTER TABLE `widget_config` DISABLE KEYS */;
INSERT INTO `widget_config` VALUES (1,1,'channels','crm','crm_quickadd_widget',1,NULL,1,'2014-04-14 14:59:03','2014-04-14 14:59:14',1),(2,1,'crm','crm','countaccounts_widget',1,NULL,1,'2014-04-23 14:44:48','2014-04-23 14:44:48',0);
/*!40000 ALTER TABLE `widget_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki`
--

DROP TABLE IF EXISTS `wiki`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dt_created` datetime NOT NULL,
  `dt_modified` datetime NOT NULL,
  `creator_id` bigint(20) NOT NULL,
  `modifier_id` bigint(20) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `owner_id` bigint(20) NOT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT '0',
  `last_modified_page_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki`
--

LOCK TABLES `wiki` WRITE;
/*!40000 ALTER TABLE `wiki` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_page`
--

DROP TABLE IF EXISTS `wiki_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_page` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `wiki_id` bigint(20) NOT NULL,
  `dt_created` datetime NOT NULL,
  `dt_modified` datetime NOT NULL,
  `creator_id` bigint(20) NOT NULL,
  `modifier_id` bigint(20) NOT NULL,
  `body` longtext COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_page`
--

LOCK TABLES `wiki_page` WRITE;
/*!40000 ALTER TABLE `wiki_page` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_page_history`
--

DROP TABLE IF EXISTS `wiki_page_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_page_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `wiki_page_id` bigint(20) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `wiki_id` bigint(20) NOT NULL,
  `dt_created` datetime NOT NULL,
  `dt_modified` datetime NOT NULL,
  `creator_id` bigint(20) NOT NULL,
  `modifier_id` bigint(20) NOT NULL,
  `body` longtext COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_page_history`
--

LOCK TABLES `wiki_page_history` WRITE;
/*!40000 ALTER TABLE `wiki_page_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki_page_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_user`
--

DROP TABLE IF EXISTS `wiki_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `wiki_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `role` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'reader',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_user`
--

LOCK TABLES `wiki_user` WRITE;
/*!40000 ALTER TABLE `wiki_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-04-24 14:21:13
